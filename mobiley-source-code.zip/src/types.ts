export type AccountType = 'individual' | 'store' | 'kiosk';

export interface User {
  id: string;
  name: string;
  phone: string;
  city: string;
  accountType: AccountType;
  avatar: string;
  coverImage: string;
  rating: number;
  ratingsCount: number;
  isVerified?: boolean;
  joinedDate: string;
  bio?: string;
}

export interface PhoneListing {
  id: string;
  title: string;
  model: string;
  price: number;
  currency: string;
  city: string;
  locationDetails: string;
  notes: string; // Max 50 characters
  images: string[]; // Up to 6 images
  sellerId: string;
  sellerName: string;
  sellerPhone: string;
  sellerType: AccountType;
  sellerAvatar: string;
  likes: number;
  dislikes: number;
  userReaction?: 'like' | 'dislike' | null;
  createdAt: number;
  expiresAt: number; // Defaults to createdAt + 7 days
}

export interface ChatMessage {
  id: string;
  senderId: string;
  receiverId: string;
  text: string;
  timestamp: number;
  read: boolean;
  listingId?: string;
  listingTitle?: string;
}

export interface Conversation {
  id: string;
  partner: {
    id: string;
    name: string;
    avatar: string;
    phone: string;
    accountType: AccountType;
    city: string;
  };
  lastMessage: ChatMessage;
  unreadCount: number;
  listingId?: string;
}

export type ScreenType =
  | 'splash'
  | 'login'
  | 'signup'
  | 'verify-otp'
  | 'forgot-password'
  | 'home'
  | 'chat'
  | 'profile';

export interface AppNotification {
  id: string;
  title: string;
  desc: string;
  time: string;
  timestamp: number;
  isRead: boolean;
  type: 'system' | 'message' | 'price' | 'alert';
  senderAvatar?: string;
  senderName?: string;
  partnerId?: string;
}

export interface PushToastData {
  id: string;
  title: string;
  body: string;
  avatar?: string;
  type: 'message' | 'system' | 'price' | 'alert';
  partnerId?: string;
  onClick?: () => void;
}
