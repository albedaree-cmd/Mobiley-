// Royalty-Free Audio Synthesizer using standard Web Audio API
// 100% mathematically synthesized without any external copyrighted audio files.
// Produces crystal-clear, harmonic notification chimes across mobile and desktop.

let audioCtx: AudioContext | null = null;
const SOUND_STORAGE_KEY = 'mobiley_notification_sound_enabled';

// Get or initialize the Web Audio context safely
function getAudioContext(): AudioContext | null {
  try {
    if (!audioCtx) {
      const AudioContextClass =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioContextClass) {
        audioCtx = new AudioContextClass();
      }
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume().catch(() => {});
    }
    return audioCtx;
  } catch {
    return null;
  }
}

// Auto-unlock audio context on first user interaction (browser policy compliance)
if (typeof window !== 'undefined') {
  const unlockAudio = () => {
    const ctx = getAudioContext();
    if (ctx && ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }
    window.removeEventListener('click', unlockAudio);
    window.removeEventListener('touchstart', unlockAudio);
    window.removeEventListener('keydown', unlockAudio);
  };
  window.addEventListener('click', unlockAudio, { passive: true });
  window.addEventListener('touchstart', unlockAudio, { passive: true });
  window.addEventListener('keydown', unlockAudio, { passive: true });
}

// Check if notification sounds are enabled in user settings
export function isNotificationSoundEnabled(): boolean {
  try {
    const stored = localStorage.getItem(SOUND_STORAGE_KEY);
    return stored === null ? true : stored === 'true';
  } catch {
    return true;
  }
}

// Toggle or set notification sound preference
export function setNotificationSoundEnabled(enabled: boolean): void {
  try {
    localStorage.setItem(SOUND_STORAGE_KEY, String(enabled));
  } catch {}
}

/**
 * Plays a pleasant, 100% royalty-free notification tone.
 * @param type 'message' (dual chime) | 'alert' (3-tone chord) | 'ding' (crystal single chime)
 */
export function playRoyaltyFreeTone(type: 'message' | 'alert' | 'ding' = 'message'): void {
  if (!isNotificationSoundEnabled()) return;

  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime;

  if (type === 'message') {
    // Elegant dual chime: E5 (659.25Hz) -> B5 (987.77Hz) with soft harmonics
    playChimeNote(ctx, 659.25, now, 0.35, 0.28);
    playChimeNote(ctx, 987.77, now + 0.09, 0.42, 0.25);
  } else if (type === 'alert') {
    // 3-tone cheerful arpeggio: C#5 (554.37Hz) -> E5 (659.25Hz) -> A5 (880Hz)
    playChimeNote(ctx, 554.37, now, 0.25, 0.2);
    playChimeNote(ctx, 659.25, now + 0.08, 0.3, 0.22);
    playChimeNote(ctx, 880.0, now + 0.16, 0.45, 0.26);
  } else {
    // Single gentle bell ding
    playChimeNote(ctx, 880.0, now, 0.4, 0.25);
  }
}

/**
 * Helper to synthesize an individual chime note with gentle decay and harmonic balance
 */
function playChimeNote(
  ctx: AudioContext,
  frequency: number,
  startTime: number,
  duration: number,
  gainLevel: number
): void {
  try {
    // Primary sine wave oscillator (pure fundamental)
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(frequency, startTime);

    // Subtle overtone oscillator (triangle wave at double frequency) for warmth and presence
    const overtone = ctx.createOscillator();
    overtone.type = 'triangle';
    overtone.frequency.setValueAtTime(frequency * 2, startTime);

    // Gain envelope node
    const gainNode = ctx.createGain();
    const overtoneGain = ctx.createGain();

    // Fundamental volume envelope
    gainNode.gain.setValueAtTime(0.001, startTime);
    gainNode.gain.linearRampToValueAtTime(gainLevel, startTime + 0.015);
    gainNode.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

    // Overtone volume envelope (quieter, faster decay for glassy bell timbre)
    overtoneGain.gain.setValueAtTime(0.001, startTime);
    overtoneGain.gain.linearRampToValueAtTime(gainLevel * 0.18, startTime + 0.01);
    overtoneGain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration * 0.6);

    // Connect audio graph
    osc.connect(gainNode);
    overtone.connect(overtoneGain);
    overtoneGain.connect(gainNode);
    gainNode.connect(ctx.destination);

    // Start and stop oscillators
    osc.start(startTime);
    overtone.start(startTime);
    osc.stop(startTime + duration + 0.05);
    overtone.stop(startTime + duration + 0.05);
  } catch {}
}

/**
 * Browser Web Notification API integration
 * Request permission if supported
 */
export async function requestWebPushPermission(): Promise<NotificationPermission> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'denied';
  }

  try {
    const permission = await Notification.requestPermission();
    return permission;
  } catch {
    return Notification.permission || 'default';
  }
}

/**
 * Trigger real browser system notification (if granted)
 */
export function sendBrowserPushNotification(
  title: string,
  body: string,
  options?: { icon?: string; tag?: string; onClick?: () => void }
): void {
  if (typeof window === 'undefined' || !('Notification' in window)) return;

  if (Notification.permission === 'granted') {
    try {
      const n = new Notification(title, {
        body,
        icon: options?.icon || 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=128&q=80',
        tag: options?.tag || 'mobiley-push-notification',
      });
      if (options?.onClick) {
        n.onclick = () => {
          window.focus();
          options.onClick?.();
          n.close();
        };
      }
    } catch {}
  }
}
