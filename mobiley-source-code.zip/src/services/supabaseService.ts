/// <reference types="vite/client" />
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { PhoneListing, User, ChatMessage, AccountType, Conversation } from '../types';
import { INITIAL_LISTINGS, INITIAL_USERS } from '../data/sudanData';
import { MOBILEY_OFFICIAL_COVER } from '../assets/mobileyCover';

export const MESSAGE_RETENTION_MS = 7 * 24 * 60 * 60 * 1000; // 7 days (أسبوع واحد)

// Storage keys
const LISTINGS_KEY = 'mobiley_listings_v1';
const USERS_KEY = 'mobiley_users_v1';
const CHATS_KEY = 'mobiley_chats_v1';
const CURRENT_USER_KEY = 'mobiley_current_user_v1';
const SAVED_LOGIN_KEY = 'mobiley_saved_login_v1';

// Check for environment variables safely
const supabaseUrl = (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_URL) || '';
const supabaseKey = (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_ANON_KEY) || '';

export const supabase: SupabaseClient | null =
  supabaseUrl && supabaseKey ? createClient(supabaseUrl, supabaseKey) : null;

// Security sanitizer helper
export function sanitizeInput(input: string, maxLength: number = 255): string {
  if (!input) return '';
  const cleaned = input
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/[<>]/g, '')
    .trim();
  return cleaned.slice(0, maxLength);
}

// 7-day expiration validation (week in milliseconds)
const ONE_WEEK_MS = 7 * 24 * 60 * 60 * 1000;

export function filterExpiredListings(listings: PhoneListing[]): PhoneListing[] {
  const currentNow = Date.now();
  return listings.filter((item) => item.expiresAt > currentNow);
}

export class DatabaseService {
  // Initialize default data if empty
  static initDatabase() {
    if (!localStorage.getItem(LISTINGS_KEY)) {
      localStorage.setItem(LISTINGS_KEY, JSON.stringify(INITIAL_LISTINGS));
    }
    if (!localStorage.getItem(USERS_KEY)) {
      localStorage.setItem(USERS_KEY, JSON.stringify(INITIAL_USERS));
    }
    if (!localStorage.getItem(CHATS_KEY)) {
      localStorage.setItem(CHATS_KEY, JSON.stringify([]));
    }
  }

  // Get active listings with auto-expiration applied
  static getListings(): PhoneListing[] {
    this.initDatabase();
    try {
      const raw = localStorage.getItem(LISTINGS_KEY);
      if (!raw) return INITIAL_LISTINGS;
      const parsed: PhoneListing[] = JSON.parse(raw);
      // Auto-filter expired
      const valid = filterExpiredListings(parsed);
      if (valid.length !== parsed.length) {
        localStorage.setItem(LISTINGS_KEY, JSON.stringify(valid));
      }
      return valid;
    } catch {
      return INITIAL_LISTINGS;
    }
  }

  // Add new listing
  static addListing(data: {
    title: string;
    model: string;
    price: number;
    city: string;
    locationDetails: string;
    notes: string;
    images: string[];
    user: User;
  }): PhoneListing {
    const listings = this.getListings();
    const now = Date.now();

    const newListing: PhoneListing = {
      id: `list-${now}-${Math.random().toString(36).substring(2, 7)}`,
      title: sanitizeInput(data.title, 80),
      model: sanitizeInput(data.model, 60),
      price: Math.max(0, Number(data.price)),
      currency: 'ج.س',
      city: sanitizeInput(data.city, 40),
      locationDetails: sanitizeInput(data.locationDetails, 80),
      notes: sanitizeInput(data.notes, 50), // 50 char limit
      images: data.images.slice(0, 6),
      sellerId: data.user.id,
      sellerName: data.user.name,
      sellerPhone: data.user.phone,
      sellerType: data.user.accountType,
      sellerAvatar: data.user.avatar,
      likes: 0,
      dislikes: 0,
      userReaction: null,
      createdAt: now,
      expiresAt: now + ONE_WEEK_MS, // Auto delete after 1 week
    };

    const updated = [newListing, ...listings];
    localStorage.setItem(LISTINGS_KEY, JSON.stringify(updated));
    return newListing;
  }

  // Toggle like or dislike
  static reactToListing(listingId: string, type: 'like' | 'dislike'): PhoneListing | null {
    const listings = this.getListings();
    const index = listings.findIndex((item) => item.id === listingId);
    if (index === -1) return null;

    const listing = { ...listings[index] };
    const currentReaction = listing.userReaction;

    if (currentReaction === type) {
      // Undo reaction
      if (type === 'like') listing.likes = Math.max(0, listing.likes - 1);
      if (type === 'dislike') listing.dislikes = Math.max(0, listing.dislikes - 1);
      listing.userReaction = null;
    } else {
      // If switching from another reaction
      if (currentReaction === 'like') listing.likes = Math.max(0, listing.likes - 1);
      if (currentReaction === 'dislike') listing.dislikes = Math.max(0, listing.dislikes - 1);

      if (type === 'like') listing.likes += 1;
      if (type === 'dislike') listing.dislikes += 1;
      listing.userReaction = type;
    }

    listings[index] = listing;
    localStorage.setItem(LISTINGS_KEY, JSON.stringify(listings));
    return listing;
  }

  // Get or create user
  static getUser(id: string): User | null {
    this.initDatabase();
    try {
      const raw = localStorage.getItem(USERS_KEY);
      const users: User[] = raw ? JSON.parse(raw) : INITIAL_USERS;
      const found = users.find((u) => u.id === id) || null;
      if (found) {
        return { ...found, coverImage: MOBILEY_OFFICIAL_COVER };
      }
      return null;
    } catch {
      return null;
    }
  }

  static saveUser(user: User): void {
    this.initDatabase();
    try {
      const userWithCover = { ...user, coverImage: MOBILEY_OFFICIAL_COVER };
      const raw = localStorage.getItem(USERS_KEY);
      const users: User[] = raw ? JSON.parse(raw) : INITIAL_USERS;
      const idx = users.findIndex((u) => u.id === user.id);
      if (idx >= 0) {
        users[idx] = userWithCover;
      } else {
        users.push(userWithCover);
      }
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
    } catch (e) {
      console.error(e);
    }
  }

  // Current session user
  static getCurrentUser(): User | null {
    try {
      const raw = localStorage.getItem(CURRENT_USER_KEY);
      if (raw) {
        const u = JSON.parse(raw);
        return { ...u, coverImage: MOBILEY_OFFICIAL_COVER };
      }
    } catch {}
    return null;
  }

  static setCurrentUser(user: User | null): void {
    if (user) {
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(CURRENT_USER_KEY);
    }
  }

  // Find existing user by Sudan phone number
  static findUserByPhone(phone: string): User | null {
    this.initDatabase();
    try {
      const raw = localStorage.getItem(USERS_KEY);
      const users: User[] = raw ? JSON.parse(raw) : INITIAL_USERS;
      const cleanTarget = phone.replace(/\D/g, '').slice(-9);
      return (
        users.find((u) => {
          const cleanU = u.phone.replace(/\D/g, '').slice(-9);
          return cleanU === cleanTarget;
        }) || null
      );
    } catch {
      return null;
    }
  }

  // Saved credentials / automatic login profile
  static getSavedLoginData(): { name: string; phone: string; city: string; autoLogin: boolean } | null {
    try {
      const raw = localStorage.getItem(SAVED_LOGIN_KEY);
      if (raw) return JSON.parse(raw);
    } catch {}
    return null;
  }

  static setSavedLoginData(data: { name: string; phone: string; city: string; autoLogin: boolean } | null): void {
    if (data) {
      localStorage.setItem(SAVED_LOGIN_KEY, JSON.stringify(data));
    } else {
      localStorage.removeItem(SAVED_LOGIN_KEY);
    }
  }

  // Delete user account permanently and wipe their data
  static deleteUserAccount(userId: string): boolean {
    this.initDatabase();
    try {
      // 1. Remove from USERS list
      const rawUsers = localStorage.getItem(USERS_KEY);
      if (rawUsers) {
        const users: User[] = JSON.parse(rawUsers);
        const filteredUsers = users.filter((u) => u.id !== userId);
        localStorage.setItem(USERS_KEY, JSON.stringify(filteredUsers));
      }

      // 2. Remove user listings
      const rawListings = localStorage.getItem(LISTINGS_KEY);
      if (rawListings) {
        const listings: PhoneListing[] = JSON.parse(rawListings);
        const filteredListings = listings.filter((l) => l.sellerId !== userId);
        localStorage.setItem(LISTINGS_KEY, JSON.stringify(filteredListings));
      }

      // 3. Remove user messages
      const rawChats = localStorage.getItem(CHATS_KEY);
      if (rawChats) {
        const chats: ChatMessage[] = JSON.parse(rawChats);
        const filteredChats = chats.filter((m) => m.senderId !== userId && m.receiverId !== userId);
        localStorage.setItem(CHATS_KEY, JSON.stringify(filteredChats));
      }

      // 4. Clear current session and saved login credentials
      this.setCurrentUser(null);
      this.setSavedLoginData(null);
      return true;
    } catch (e) {
      console.error('Failed to delete user account:', e);
      return false;
    }
  }

  // Rate user profile
  static rateUser(userId: string, score: number): User | null {
    const user = this.getUser(userId);
    if (!user) return null;

    const currentTotal = user.rating * user.ratingsCount;
    const newCount = user.ratingsCount + 1;
    const newRating = Number(((currentTotal + score) / newCount).toFixed(1));

    const updatedUser = {
      ...user,
      rating: newRating,
      ratingsCount: newCount,
    };

    this.saveUser(updatedUser);
    return updatedUser;
  }

  // Purge any messages older than 7 days automatically (تحذف تلقائياً بعد أسبوع)
  static purgeExpiredMessages(): ChatMessage[] {
    try {
      const raw = localStorage.getItem(CHATS_KEY);
      if (!raw) return [];
      const all: ChatMessage[] = JSON.parse(raw);
      const now = Date.now();
      const valid = all.filter((m) => now - m.timestamp < MESSAGE_RETENTION_MS);
      if (valid.length !== all.length) {
        localStorage.setItem(CHATS_KEY, JSON.stringify(valid));
      }
      return valid;
    } catch {
      return [];
    }
  }

  // Messages / Chat
  static getMessages(partnerId: string, currentUserId: string): ChatMessage[] {
    this.initDatabase();
    try {
      const all = this.purgeExpiredMessages();
      return all.filter(
        (m) =>
          (m.senderId === currentUserId && m.receiverId === partnerId) ||
          (m.senderId === partnerId && m.receiverId === currentUserId)
      );
    } catch {
      return [];
    }
  }

  static sendMessage(msg: Omit<ChatMessage, 'id' | 'timestamp' | 'read'>): ChatMessage {
    this.initDatabase();
    const newMsg: ChatMessage = {
      ...msg,
      id: `msg-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: Date.now(),
      read: false,
    };

    try {
      const all = this.purgeExpiredMessages();
      all.push(newMsg);
      localStorage.setItem(CHATS_KEY, JSON.stringify(all));
    } catch (e) {
      console.error(e);
    }
    return newMsg;
  }

  // Unread messages count
  static getUnreadCount(userId: string): number {
    this.initDatabase();
    try {
      const all = this.purgeExpiredMessages();
      return all.filter((m) => m.receiverId === userId && !m.read).length;
    } catch {
      return 0;
    }
  }

  // Mark all messages in a conversation as read
  static markConversationAsRead(partnerId: string, currentUserId: string): void {
    this.initDatabase();
    try {
      const all = this.purgeExpiredMessages();
      let changed = false;
      all.forEach((m) => {
        if (m.senderId === partnerId && m.receiverId === currentUserId && !m.read) {
          m.read = true;
          changed = true;
        }
      });
      if (changed) {
        localStorage.setItem(CHATS_KEY, JSON.stringify(all));
      }
    } catch (e) {
      console.error(e);
    }
  }

  // Get list of conversations for an active user
  static getConversations(currentUserId: string): Conversation[] {
    this.initDatabase();
    try {
      let all = this.purgeExpiredMessages();

      // Seed initial realistic conversations if none exist for this user
      const userMessages = all.filter(
        (m) => m.senderId === currentUserId || m.receiverId === currentUserId
      );

      if (userMessages.length === 0) {
        const seedMessages: ChatMessage[] = [
          {
            id: `seed-chat-1-${currentUserId}`,
            senderId: 'user-ahmed-sdn',
            receiverId: currentUserId,
            text: 'مرحباً بك في متجر النيلين! بخصوص الآيفون 15 برو ماكس، الجهاز متوفر مع الضمان والفاتورة.',
            timestamp: Date.now() - 12 * 60 * 1000,
            read: false,
            listingId: 'list-1',
            listingTitle: 'iPhone 15 Pro Max تيتانيوم طبيعي 256GB',
          },
          {
            id: `seed-chat-2-${currentUserId}`,
            senderId: 'user-mohammed-kiosk',
            receiverId: currentUserId,
            text: 'سلام عليكم يا غالي، متواجد في بترينة سوق بورتسودان، وأي جهاز بنفحصه ليك بحضورك.',
            timestamp: Date.now() - 3 * 3600 * 1000,
            read: true,
            listingId: 'list-2',
            listingTitle: 'Samsung Galaxy S24 Ultra رمادي تيتانيوم',
          },
          {
            id: `seed-chat-3-${currentUserId}`,
            senderId: 'user-sara-indiv',
            receiverId: currentUserId,
            text: 'أهلاً أخي، الهاتف استخدامي الشخصي ونظيف جداً بدون أي خدش، ممكن نتواصل ونرتب للمعاينة.',
            timestamp: Date.now() - 26 * 3600 * 1000,
            read: true,
            listingId: 'list-3',
            listingTitle: 'Google Pixel 8 Pro أزرق سماوي 128GB',
          },
        ];

        all = [...all, ...seedMessages];
        localStorage.setItem(CHATS_KEY, JSON.stringify(all));
      }

      // Group by partner ID
      const conversationMap = new Map<string, { lastMsg: ChatMessage; unread: number }>();

      all.forEach((msg) => {
        let partnerId: string | null = null;
        if (msg.senderId === currentUserId) {
          partnerId = msg.receiverId;
        } else if (msg.receiverId === currentUserId) {
          partnerId = msg.senderId;
        }

        if (!partnerId) return;

        const currentEntry = conversationMap.get(partnerId);
        const isUnread = msg.receiverId === currentUserId && !msg.read;

        if (!currentEntry) {
          conversationMap.set(partnerId, {
            lastMsg: msg,
            unread: isUnread ? 1 : 0,
          });
        } else {
          if (msg.timestamp > currentEntry.lastMsg.timestamp) {
            currentEntry.lastMsg = msg;
          }
          if (isUnread) {
            currentEntry.unread += 1;
          }
        }
      });

      const result: Conversation[] = [];
      conversationMap.forEach((entry, partnerId) => {
        const partnerUser = this.getUser(partnerId) || {
          id: partnerId,
          name: 'مستخدم mobiley',
          phone: '+249912345678',
          city: 'الخرطوم',
          accountType: 'individual' as AccountType,
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
          coverImage: '',
          rating: 5,
          ratingsCount: 1,
          joinedDate: '2024',
        };

        result.push({
          id: `conv-${partnerId}`,
          partner: {
            id: partnerUser.id,
            name: partnerUser.name,
            avatar: partnerUser.avatar,
            phone: partnerUser.phone,
            accountType: partnerUser.accountType,
            city: partnerUser.city,
          },
          lastMessage: entry.lastMsg,
          unreadCount: entry.unread,
          listingId: entry.lastMsg.listingId,
        });
      });

      // Sort with newest messages first
      result.sort((a, b) => b.lastMessage.timestamp - a.lastMessage.timestamp);
      return result;
    } catch {
      return [];
    }
  }

  // Delete a conversation with a partner
  static deleteConversation(partnerId: string, currentUserId: string): void {
    this.initDatabase();
    try {
      const raw = localStorage.getItem(CHATS_KEY);
      if (!raw) return;
      const all: ChatMessage[] = JSON.parse(raw);
      const filtered = all.filter(
        (m) =>
          !(
            (m.senderId === currentUserId && m.receiverId === partnerId) ||
            (m.senderId === partnerId && m.receiverId === currentUserId)
          )
      );
      localStorage.setItem(CHATS_KEY, JSON.stringify(filtered));
    } catch {}
  }
}
