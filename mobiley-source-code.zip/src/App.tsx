import React, { useState, useEffect } from 'react';
import {
  Plus,
  Search,
  X,
  Filter,
  SlidersHorizontal,
  Smartphone,
  Store,
  ShoppingBag,
  UserCheck,
  CheckCircle,
  Sparkles,
  SmartphoneNfc,
  Layers,
  ArrowUpDown,
  RotateCcw,
} from 'lucide-react';
import { ScreenType, User, PhoneListing, AccountType } from './types';
import { DatabaseService, filterExpiredListings } from './services/supabaseService';
import { SUDAN_CITIES, ACCOUNT_TYPE_CONFIG } from './data/sudanData';

// Screens & Components
import { SplashScreen } from './components/SplashScreen';
import { LoginScreen } from './components/LoginScreen';
import { SignupScreen } from './components/SignupScreen';
import { OtpVerificationScreen } from './components/OtpVerificationScreen';
import { ForgotPasswordScreen } from './components/ForgotPasswordScreen';
import { NetworkOfflineDialog } from './components/NetworkOfflineDialog';
import { MainToolbar } from './components/MainToolbar';
import { ListingCard } from './components/ListingCard';
import { NewListingModal } from './components/NewListingModal';
import { PullToRefreshContainer } from './components/PullToRefreshContainer';
import { ChatRoomModal } from './components/ChatRoomModal';
import { ProfileModal } from './components/ProfileModal';
import { InfoModals } from './components/InfoModals';
import { KotlinCodeViewerModal } from './components/KotlinCodeViewerModal';
import { BottomNavBar, BottomNavTab } from './components/BottomNavBar';
import { NotificationsModal } from './components/NotificationsModal';
import { ConversationsListModal } from './components/ConversationsListModal';
import { PushNotificationToast } from './components/PushNotificationToast';
import { SwipeBackDetector } from './components/SwipeBackDetector';
import { PushToastData } from './types';
import {
  playRoyaltyFreeTone,
  sendBrowserPushNotification,
} from './services/notificationSound';
import { INITIAL_USERS } from './data/sudanData';

export default function App() {
  // Screen navigation state
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('splash');
  const [activeBottomTab, setActiveBottomTab] = useState<BottomNavTab>('home');
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [currentPushToast, setCurrentPushToast] = useState<PushToastData | null>(null);

  // Network offline state (Facebook-style dialog)
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [isRetryingOffline, setIsRetryingOffline] = useState(false);

  // Authenticated user state
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const existing = DatabaseService.getCurrentUser();
    if (existing) return existing;
    const savedLogin = DatabaseService.getSavedLoginData();
    if (savedLogin && savedLogin.phone) {
      const matched = DatabaseService.findUserByPhone(savedLogin.phone);
      if (matched) {
        DatabaseService.setCurrentUser(matched);
        return matched;
      }
    }
    return null;
  });

  // Signup/Login flow temporary state
  const [pendingSignupData, setPendingSignupData] = useState<{
    name: string;
    phone: string;
    city: string;
    accountType?: AccountType;
    autoLogin?: boolean;
  } | null>(null);
  const [currentOtpCode, setCurrentOtpCode] = useState('8392');

  // Phone listings
  const [listings, setListings] = useState<PhoneListing[]>(() => DatabaseService.getListings());

  // Filter & Search
  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [isNewListingModalOpen, setIsNewListingModalOpen] = useState(false);
  const [infoModalType, setInfoModalType] = useState<'privacy' | 'about' | 'contact' | null>(null);
  const [isKotlinCodeModalOpen, setIsKotlinCodeModalOpen] = useState(false);

  // Language & Night Mode Settings
  const [language, setLanguage] = useState<'ar' | 'en'>(() => {
    return (localStorage.getItem('mobiley_lang') as 'ar' | 'en') || 'ar';
  });
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('mobiley_dark') !== 'false';
  });

  const handleLanguageChange = (lang: 'ar' | 'en') => {
    setLanguage(lang);
    localStorage.setItem('mobiley_lang', lang);
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  };

  const handleToggleDarkMode = (dark: boolean) => {
    setIsDarkMode(dark);
    localStorage.setItem('mobiley_dark', String(dark));
    if (dark) {
      document.documentElement.classList.remove('light-theme');
    } else {
      document.documentElement.classList.add('light-theme');
    }
  };

  const handleDeleteAccount = () => {
    if (!currentUser) return;
    const deletedId = currentUser.id;
    const success = DatabaseService.deleteUserAccount(deletedId);
    if (success) {
      setCurrentUser(null);
      setListings(DatabaseService.getListings());
      setCurrentPushToast({
        id: 'toast-del-' + Date.now(),
        type: 'alert',
        title: language === 'ar' ? 'تم حذف الحساب نهائياً' : 'Account Deleted Permanently',
        body:
          language === 'ar'
            ? 'تم حذف حسابك وجميع إعلاناتك ورسائلك بالكامل من التطبيق.'
            : 'Your account and listings have been wiped completely.',
        timestamp: Date.now(),
      });
      playRoyaltyFreeTone('alert');
      setCurrentScreen('login');
    }
  };

  // Active chat & conversations state
  const [isConversationsListOpen, setIsConversationsListOpen] = useState(false);
  const [activeChatSeller, setActiveChatSeller] = useState<User | null>(null);
  const [activeChatListing, setActiveChatListing] = useState<PhoneListing | null>(null);

  // Active profile view
  const [viewingProfileUser, setViewingProfileUser] = useState<User | null>(null);

  // Phone Frame simulator toggle
  const [isAndroidFrameEnabled, setIsAndroidFrameEnabled] = useState(false);

  // Swipe-to-back state calculation: check if any modal, room, or subview is open
  const canGoBack = Boolean(
    activeChatSeller ||
    viewingProfileUser ||
    isNewListingModalOpen ||
    isConversationsListOpen ||
    isNotificationsOpen ||
    infoModalType ||
    isKotlinCodeModalOpen ||
    currentScreen === 'signup' ||
    currentScreen === 'verify-otp' ||
    currentScreen === 'forgot-password' ||
    searchQuery
  );

  const handleSwipeBack = () => {
    if (activeChatSeller) {
      setActiveChatSeller(null);
      return;
    }
    if (viewingProfileUser) {
      setViewingProfileUser(null);
      return;
    }
    if (isNewListingModalOpen) {
      setIsNewListingModalOpen(false);
      return;
    }
    if (isConversationsListOpen) {
      setIsConversationsListOpen(false);
      return;
    }
    if (isNotificationsOpen) {
      setIsNotificationsOpen(false);
      return;
    }
    if (infoModalType) {
      setInfoModalType(null);
      return;
    }
    if (isKotlinCodeModalOpen) {
      setIsKotlinCodeModalOpen(false);
      return;
    }
    if (currentScreen === 'signup' || currentScreen === 'verify-otp' || currentScreen === 'forgot-password') {
      setCurrentScreen('login');
      return;
    }
    if (searchQuery) {
      setSearchQuery('');
      return;
    }
  };

  // Offline detection listener
  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Periodic check for auto-deleting 1-week expired listings
  useEffect(() => {
    const checkInterval = setInterval(() => {
      setListings((current) => filterExpiredListings(current));
    }, 60000); // Check every minute

    return () => clearInterval(checkInterval);
  }, []);

  // Push notification dispatcher
  const triggerPush = (data: {
    title: string;
    body: string;
    avatar?: string;
    type?: 'message' | 'system' | 'price' | 'alert';
    partnerId?: string;
    onClick?: () => void;
  }) => {
    // 1. Synthesize royalty-free notification tone
    playRoyaltyFreeTone(data.type === 'message' ? 'message' : 'alert');

    // 2. Send browser push notification if permission is granted
    sendBrowserPushNotification(data.title, data.body, {
      icon: data.avatar,
      onClick: data.onClick,
    });

    // 3. Show floating in-app banner toast
    setCurrentPushToast({
      id: String(Date.now()),
      title: data.title,
      body: data.body,
      avatar: data.avatar,
      type: data.type || 'message',
      partnerId: data.partnerId,
      onClick: data.onClick,
    });
  };

  // Push notifications background generator (simulates live marketplace notifications)
  useEffect(() => {
    if (currentScreen !== 'home') return;

    // First push notification after 10 seconds to greet and demonstrate the royalty-free chime
    const initialTimer = setTimeout(() => {
      const seller = INITIAL_USERS[0];
      triggerPush({
        title: seller.name,
        body: 'السلام عليكم، هل ترغب في الاستفسار عن الهواتف المتوفرة اليوم؟',
        avatar: seller.avatar,
        type: 'message',
        partnerId: seller.id,
        onClick: () => {
          setActiveChatSeller(seller);
          setActiveChatListing(listings[0] || null);
        },
      });
    }, 10000);

    // Periodic push notifications every 75 seconds
    const interval = setInterval(() => {
      const scenarios = [
        {
          title: 'سوق الخرطوم - تنبيه الأسعار',
          body: 'انخفاض في متوسط أسعار iPhone 15 Pro Max اليوم بنسبة 3%.',
          type: 'price' as const,
          onClick: () => setIsNotificationsOpen(true),
        },
        {
          title: INITIAL_USERS[1]?.name || 'معتز عوض (متجر)',
          body: 'مرحباً، متوفر لدينا تشكيلة هواتف سامسونج جديدة بضمان وفاتورة.',
          avatar: INITIAL_USERS[1]?.avatar,
          type: 'message' as const,
          partnerId: INITIAL_USERS[1]?.id,
          onClick: () => {
            if (INITIAL_USERS[1]) {
              setActiveChatSeller(INITIAL_USERS[1]);
              setActiveChatListing(listings[1] || null);
            }
          },
        },
        {
          title: 'تنبيه الأمان من Mobiley',
          body: 'تذكير: جميع رسائل الدردشة تُحذف تلقائياً بعد مرور أسبوع كامل.',
          type: 'alert' as const,
          onClick: () => setIsNotificationsOpen(true),
        },
      ];

      const chosen = scenarios[Math.floor(Math.random() * scenarios.length)];
      triggerPush(chosen);
    }, 75000);

    return () => {
      clearTimeout(initialTimer);
      clearInterval(interval);
    };
  }, [currentScreen, listings]);

  const handlePushToastAction = (toast: PushToastData) => {
    setCurrentPushToast(null);
    if (toast.type === 'message' && toast.partnerId) {
      const partner = DatabaseService.getUser(toast.partnerId) || INITIAL_USERS.find(u => u.id === toast.partnerId);
      if (partner) {
        setActiveChatSeller(partner);
        setActiveChatListing(listings[0] || null);
        return;
      }
    }
    if (toast.onClick) {
      toast.onClick();
    } else {
      setIsNotificationsOpen(true);
    }
  };

  // Manual retry handler for offline dialog
  const handleRetryOffline = () => {
    setIsRetryingOffline(true);
    setTimeout(() => {
      setIsRetryingOffline(false);
      setIsOffline(false);
    }, 1200);
  };

  // Pull to refresh handler
  const handleRefreshListings = async () => {
    await new Promise((resolve) => setTimeout(resolve, 800));
    const fresh = DatabaseService.getListings();
    setListings(fresh);
  };

  // React to listing (Like / Dislike)
  const handleReactToListing = (listingId: string, type: 'like' | 'dislike') => {
    const updated = DatabaseService.reactToListing(listingId, type);
    if (updated) {
      setListings((prev) => prev.map((item) => (item.id === listingId ? updated : item)));
    }
  };

  // Open direct chat with seller
  const handleOpenChatWithSeller = (sellerId: string, listing?: PhoneListing) => {
    const seller = DatabaseService.getUser(sellerId);
    if (seller) {
      setActiveChatSeller(seller);
      setActiveChatListing(listing || null);
    }
  };

  // Open profile modal
  const handleOpenProfile = (userToView: User) => {
    setViewingProfileUser(userToView);
  };

  // New listing publish
  const handlePublishListing = (data: {
    title: string;
    model: string;
    price: number;
    city: string;
    locationDetails: string;
    notes: string;
    images: string[];
  }) => {
    const userToUse = currentUser || {
      id: 'guest-user',
      name: 'معلن جديد',
      phone: '+249912345678',
      city: data.city,
      accountType: 'store' as AccountType,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
      coverImage: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=1000&auto=format&fit=crop&q=80',
      rating: 5.0,
      ratingsCount: 1,
      joinedDate: 'اليوم',
    };

    const newCreated = DatabaseService.addListing({
      ...data,
      user: userToUse,
    });

    setListings((prev) => [newCreated, ...prev]);
  };

  // Signup / Login -> send WhatsApp OTP
  const handleSendWhatsAppOtp = (data: {
    name: string;
    phone: string;
    city: string;
    accountType?: AccountType;
    autoLogin?: boolean;
  }) => {
    const randomOtp = Math.floor(1000 + Math.random() * 9000).toString();
    setCurrentOtpCode(randomOtp);
    setPendingSignupData(data);
    setCurrentScreen('verify-otp');
  };

  // OTP verified successfully
  const handleOtpVerified = () => {
    if (!pendingSignupData) return;

    // Check if user already exists with this phone
    const existing = DatabaseService.findUserByPhone(pendingSignupData.phone);

    const userToSave: User = existing
      ? {
          ...existing,
          name: pendingSignupData.name || existing.name,
          city: pendingSignupData.city || existing.city,
        }
      : {
          id: `user-${Date.now()}`,
          name: pendingSignupData.name,
          phone: pendingSignupData.phone,
          city: pendingSignupData.city,
          accountType: pendingSignupData.accountType || 'individual',
          avatar:
            'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
          coverImage:
            'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=1000&auto=format&fit=crop&q=80',
          rating: 5.0,
          ratingsCount: 1,
          isVerified: true,
          joinedDate: 'اليوم',
          bio: '',
        };

    DatabaseService.saveUser(userToSave);
    DatabaseService.setCurrentUser(userToSave);
    DatabaseService.setSavedLoginData({
      name: userToSave.name,
      phone: userToSave.phone,
      city: userToSave.city,
      autoLogin: pendingSignupData.autoLogin ?? true,
    });
    setCurrentUser(userToSave);
    setCurrentScreen('home');
  };

  // Filtered listings
  const filteredListings = listings.filter((item) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      item.title.toLowerCase().includes(q) ||
      item.model.toLowerCase().includes(q) ||
      item.notes.toLowerCase().includes(q) ||
      item.city.toLowerCase().includes(q) ||
      item.sellerName.toLowerCase().includes(q)
    );
  });

  const unreadCount = currentUser ? DatabaseService.getUnreadCount(currentUser.id) || 1 : 1;

  // Screen 1: Splash Screen
  if (currentScreen === 'splash') {
    return (
      <>
        <SplashScreen
          onComplete={() => {
            // إذا كان المستخدم مسجلاً مسبقاً يدخل مباشرة إلى الصفحة الرئيسية
            const activeUser = currentUser || DatabaseService.getCurrentUser();
            const savedLogin = DatabaseService.getSavedLoginData();
            if (activeUser) {
              setCurrentUser(activeUser);
              setCurrentScreen('home');
              return;
            }
            if (savedLogin && savedLogin.phone) {
              const matchedUser = DatabaseService.findUserByPhone(savedLogin.phone);
              if (matchedUser) {
                DatabaseService.setCurrentUser(matchedUser);
                setCurrentUser(matchedUser);
                setCurrentScreen('home');
                return;
              }
              const restoredUser: User = {
                id: `user-${Date.now()}`,
                name: savedLogin.name || 'مستخدم',
                phone: savedLogin.phone,
                city: savedLogin.city || 'الخرطوم',
                accountType: 'individual',
                avatar:
                  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
                coverImage:
                  'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=1000&auto=format&fit=crop&q=80',
                rating: 5.0,
                ratingsCount: 1,
                isVerified: true,
                joinedDate: 'اليوم',
              };
              DatabaseService.saveUser(restoredUser);
              DatabaseService.setCurrentUser(restoredUser);
              setCurrentUser(restoredUser);
              setCurrentScreen('home');
              return;
            }
            setCurrentScreen('login');
          }}
        />
        <NetworkOfflineDialog
          isOpen={isOffline}
          onRetry={handleRetryOffline}
          isRetrying={isRetryingOffline}
        />
      </>
    );
  }

  // Screen 2: Login Screen (Name, Phone, City, AutoLogin, and Create Account button)
  if (currentScreen === 'login' || currentScreen === 'signup') {
    return (
      <SwipeBackDetector canGoBack={canGoBack} onBack={handleSwipeBack}>
        <LoginScreen
          onLoginSuccess={(user) => {
            setCurrentUser(user);
            setCurrentScreen('home');
          }}
          onSendWhatsAppOtp={handleSendWhatsAppOtp}
        />
        <NetworkOfflineDialog
          isOpen={isOffline}
          onRetry={handleRetryOffline}
          isRetrying={isRetryingOffline}
        />
      </SwipeBackDetector>
    );
  }

  // Screen 4: OTP Verification Screen
  if (currentScreen === 'verify-otp') {
    return (
      <SwipeBackDetector canGoBack={canGoBack} onBack={handleSwipeBack}>
        <OtpVerificationScreen
          phone={pendingSignupData?.phone || '+249912345678'}
          demoCode={currentOtpCode}
          onVerifySuccess={handleOtpVerified}
          onBack={() => setCurrentScreen('login')}
        />
        <NetworkOfflineDialog
          isOpen={isOffline}
          onRetry={handleRetryOffline}
          isRetrying={isRetryingOffline}
        />
      </SwipeBackDetector>
    );
  }

  // Screen 5: Forgot Password Screen
  if (currentScreen === 'forgot-password') {
    return (
      <SwipeBackDetector canGoBack={canGoBack} onBack={handleSwipeBack}>
        <ForgotPasswordScreen
          onBackToLogin={() => setCurrentScreen('login')}
          onResetSuccess={() => setCurrentScreen('login')}
        />
        <NetworkOfflineDialog
          isOpen={isOffline}
          onRetry={handleRetryOffline}
          isRetrying={isRetryingOffline}
        />
      </SwipeBackDetector>
    );
  }

  // Screen 6: Main Screen (Home)
  return (
    <SwipeBackDetector canGoBack={canGoBack} onBack={handleSwipeBack}>
      <div className={`min-h-screen ${isDarkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900 light-theme'} flex flex-col items-center justify-start selection:bg-emerald-500 selection:text-white`}>
      {/* Top frame switcher bar (optional Android frame vs fullscreen) */}
      <div className="w-full bg-slate-900/60 border-b border-slate-800/80 px-4 py-1.5 flex items-center justify-between text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-semibold text-slate-200">تطبيق أندرويد mobiley متصل بالخادم</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsAndroidFrameEnabled(!isAndroidFrameEnabled)}
            className="px-2.5 py-0.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition flex items-center gap-1.5 text-[11px] cursor-pointer"
          >
            <SmartphoneNfc className="w-3.5 h-3.5 text-emerald-400" />
            <span>{isAndroidFrameEnabled ? 'عرض ملء الشاشة' : 'إطار هاتف أندرويد'}</span>
          </button>
        </div>
      </div>

      {/* Main Container - supports optional realistic Android Phone Shell or standard responsive */}
      <div
        className={`w-full flex-1 flex flex-col transition-all duration-300 ${
          isAndroidFrameEnabled
            ? 'max-w-[420px] my-4 rounded-[44px] border-[8px] border-slate-800 shadow-2xl shadow-emerald-950/40 bg-slate-950 overflow-hidden relative min-h-[850px]'
            : 'max-w-md bg-slate-950 min-h-screen relative'
        }`}
      >
        {/* Android Native Status Bar when in frame mode */}
        {isAndroidFrameEnabled && (
          <div className="h-7 bg-slate-900/90 text-[10px] text-slate-400 flex items-center justify-between px-6 font-mono shrink-0 border-b border-slate-800">
            <span>09:41</span>
            <div className="w-16 h-3 bg-black rounded-full mx-auto" />
            <div className="flex items-center gap-1.5 text-emerald-400">
              <span>5G</span>
              <span>100%</span>
            </div>
          </div>
        )}

        {/* 1. Main Toolbar with "mobiley", Messenger chat icon with notification badge, and 3-dots menu */}
        <MainToolbar
          currentUser={currentUser}
          unreadCount={unreadCount}
          onOpenChats={() => {
            setIsConversationsListOpen(true);
          }}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          onOpenProfile={(user) => handleOpenProfile(user)}
          onOpenPrivacyPolicy={() => setInfoModalType('privacy')}
          onOpenAbout={() => setInfoModalType('about')}
          onOpenContact={() => setInfoModalType('contact')}
          onOpenKotlinCode={() => setIsKotlinCodeModalOpen(true)}
          onLogout={() => {
            DatabaseService.setCurrentUser(null);
            DatabaseService.setSavedLoginData(null);
            setCurrentUser(null);
            setCurrentScreen('login');
          }}
        />

        {/* Pull to Refresh Container wrapping the listings feed */}
        <PullToRefreshContainer onRefresh={handleRefreshListings}>
          <div className="p-4 space-y-4 pb-24">
            {/* Active search pill if query entered */}
            {searchQuery.trim() && (
              <div className="flex items-center justify-between bg-blue-950/40 border border-[#1877F2]/40 rounded-xl px-3 py-1.5 text-xs text-slate-200">
                <span className="flex items-center gap-1.5 truncate">
                  <Search className="w-3.5 h-3.5 text-[#1877F2] shrink-0" />
                  <span>نتائج البحث عن: <strong className="text-white font-bold">"{searchQuery}"</strong></span>
                </span>
                <button
                  onClick={() => setSearchQuery('')}
                  className="text-xs text-blue-300 hover:text-white mr-2 shrink-0 flex items-center gap-1 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                  <span>مسح</span>
                </button>
              </div>
            )}

            {/* Active Listing Cards Stream */}
            <div className="space-y-4">
              {filteredListings.length === 0 ? (
                <div className="p-8 text-center bg-slate-900/60 border border-slate-800 rounded-3xl">
                  <Smartphone className="w-10 h-10 text-slate-600 mx-auto mb-2" />
                  <h4 className="font-bold text-sm text-white">لا توجد عروض مطابقة</h4>
                  <p className="text-xs text-slate-400 mt-1">
                    جرب البحث بكلمات أو ماركات أخرى
                  </p>
                  <button
                    onClick={() => {
                      setSearchQuery('');
                    }}
                    className="mt-3 px-3 py-1.5 bg-slate-800 text-emerald-400 text-xs rounded-xl font-medium cursor-pointer"
                  >
                    مسح البحث
                  </button>
                </div>
              ) : (
                filteredListings.map((listing, idx) => (
                  <ListingCard
                    key={listing.id}
                    listing={listing}
                    priority={idx < 2}
                    onLike={(id) => handleReactToListing(id, 'like')}
                    onDislike={(id) => handleReactToListing(id, 'dislike')}
                    onOpenChat={(sellerId, item) => handleOpenChatWithSeller(sellerId, item)}
                    onViewSellerProfile={(sellerId) => {
                      const userToView = DatabaseService.getUser(sellerId);
                      if (userToView) handleOpenProfile(userToView);
                    }}
                  />
                ))
              )}
            </div>
          </div>
        </PullToRefreshContainer>

        {/* Floating Action Button (FAB) (+) situated above Bottom Bar */}
        <button
          onClick={() => setIsNewListingModalOpen(true)}
          title="نشر عرض هاتف جديد"
          className="fixed sm:absolute bottom-20 right-5 z-40 w-13 h-13 rounded-full bg-gradient-to-tr from-emerald-600 via-teal-500 to-green-500 text-white flex items-center justify-center shadow-xl shadow-emerald-950/80 hover:scale-105 active:scale-95 transition cursor-pointer border-2 border-emerald-400/40"
        >
          <Plus className="w-6 h-6 stroke-[2.5]" />
        </button>

        {/* Bottom Navigation Bar with (home - chat - notificiosn - profile) as requested */}
        <BottomNavBar
          activeTab={activeBottomTab}
          onSelectTab={(tab) => {
            setActiveBottomTab(tab);
            if (tab === 'home') {
              window.scrollTo({ top: 0, behavior: 'smooth' });
            } else if (tab === 'chat') {
              setIsConversationsListOpen(true);
            } else if (tab === 'notifications') {
              setIsNotificationsOpen(true);
            } else if (tab === 'profile') {
              if (currentUser) {
                handleOpenProfile(currentUser);
              } else {
                const guestUser = DatabaseService.getUser('user-ahmed-sdn');
                if (guestUser) handleOpenProfile(guestUser);
              }
            }
          }}
          unreadChatCount={unreadCount}
          unreadNotificationCount={2}
          currentUser={currentUser}
        />
      </div>

      {/* Conversations List Modal - قائمة الأشخاص الذين تتراسل معهم */}
      <ConversationsListModal
        isOpen={isConversationsListOpen}
        onClose={() => {
          setIsConversationsListOpen(false);
          setActiveBottomTab('home');
        }}
        currentUser={
          currentUser || {
            id: 'guest',
            name: 'مستخدم جديد',
            phone: '+249912345678',
            city: 'الخرطوم',
            accountType: 'individual',
            avatar:
              'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
            coverImage: '',
            rating: 5,
            ratingsCount: 1,
            joinedDate: 'اليوم',
          }
        }
        allListings={listings}
        onSelectConversation={(partner, listing) => {
          setActiveChatSeller(partner);
          setActiveChatListing(listing || null);
          setIsConversationsListOpen(false);
        }}
      />

      {/* Notifications Modal */}
      <NotificationsModal
        isOpen={isNotificationsOpen}
        onClose={() => {
          setIsNotificationsOpen(false);
          setActiveBottomTab('home');
        }}
        onOpenChats={() => {
          setIsNotificationsOpen(false);
          setIsConversationsListOpen(true);
        }}
      />

      {/* Facebook-style Offline Dialog */}
      <NetworkOfflineDialog
        isOpen={isOffline}
        onRetry={handleRetryOffline}
        isRetrying={isRetryingOffline}
      />

      {/* New Listing Modal Dialog (smaller than main screen as requested) */}
      <NewListingModal
        isOpen={isNewListingModalOpen}
        onClose={() => setIsNewListingModalOpen(false)}
        onSubmit={handlePublishListing}
      />

      {/* Chat Room Modal */}
      {activeChatSeller && (
        <ChatRoomModal
          isOpen={Boolean(activeChatSeller)}
          onClose={() => setActiveChatSeller(null)}
          onBackToConversations={() => {
            setActiveChatSeller(null);
            setIsConversationsListOpen(true);
          }}
          currentUser={
            currentUser || {
              id: 'guest',
              name: 'مشتري مهتم',
              phone: '+249912345678',
              city: 'الخرطوم',
              accountType: 'individual',
              avatar:
                'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
              coverImage: '',
              rating: 5,
              ratingsCount: 1,
              joinedDate: 'اليوم',
            }
          }
          seller={activeChatSeller}
          listingContext={activeChatListing}
        />
      )}

      {/* Profile Modal */}
      {viewingProfileUser && (
        <ProfileModal
          isOpen={Boolean(viewingProfileUser)}
          onClose={() => setViewingProfileUser(null)}
          user={viewingProfileUser}
          userListings={listings.filter(
            (item) => item.sellerId === viewingProfileUser.id || item.sellerName === viewingProfileUser.name
          )}
          isCurrentUser={currentUser?.id === viewingProfileUser.id}
          onOpenChatWithUser={(targetUser, listing) => {
            setViewingProfileUser(null);
            setActiveChatSeller(targetUser);
            setActiveChatListing(listing || null);
          }}
        />
      )}

      {/* 3-dots info modals (Privacy Policy, About Us, Contact Us) */}
      <InfoModals type={infoModalType} onClose={() => setInfoModalType(null)} />

      {/* Native Kotlin Code viewer modal */}
      <KotlinCodeViewerModal
        isOpen={isKotlinCodeModalOpen}
        onClose={() => setIsKotlinCodeModalOpen(false)}
      />

      {/* Floating Push Notification Banner with Royalty-Free Chime */}
      <PushNotificationToast
        toast={currentPushToast}
        onDismiss={() => setCurrentPushToast(null)}
        onAction={handlePushToastAction}
      />
    </div>
    </SwipeBackDetector>
  );
}
