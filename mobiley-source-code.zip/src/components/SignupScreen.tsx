import React, { useState } from 'react';
import {
  User,
  Phone,
  Lock,
  Eye,
  EyeOff,
  MapPin,
  AlertCircle,
  ArrowRight,
  Send,
} from 'lucide-react';
import { ModernAnimatedPhone } from './ModernAnimatedPhone';
import { SUDAN_CITIES } from '../data/sudanData';
import { AccountType } from '../types';
import { sanitizeInput } from '../services/supabaseService';

interface SignupScreenProps {
  onSendWhatsAppOtp: (pendingUserData: {
    name: string;
    phone: string;
    city: string;
    accountType: AccountType;
    password: string;
  }) => void;
  onNavigateToLogin: () => void;
}

export const SignupScreen: React.FC<SignupScreenProps> = ({
  onSendWhatsAppOtp,
  onNavigateToLogin,
}) => {
  const [name, setName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [city, setCity] = useState(SUDAN_CITIES[0]);
  const [accountType, setAccountType] = useState<AccountType>('individual');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const cleanName = sanitizeInput(name);
    if (!cleanName || cleanName.length < 3) {
      setErrorMsg('يرجى إدخال اسم ثلاثي أو اسم المتجر بشكل صحيح');
      return;
    }

    const cleanPhone = sanitizeInput(phoneNumber).replace(/\s+/g, '');
    if (!cleanPhone || cleanPhone.length < 9) {
      setErrorMsg('يرجى إدخال رقم هاتف سوداني صحيح مكون من 9 أرقام (مثلاً: 912345678)');
      return;
    }

    if (!password || password.length < 6) {
      setErrorMsg('يجب أن لا تقل كلمة السر عن 6 خانات لتأمين حسابك');
      return;
    }

    if (password !== confirmPassword) {
      setErrorMsg('كلمتا السر غير متطابقتين، يرجى إعادة التحقق');
      return;
    }

    setIsSubmitting(true);

    const fullSudanPhone = cleanPhone.startsWith('+249')
      ? cleanPhone
      : cleanPhone.startsWith('0')
      ? `+249${cleanPhone.slice(1)}`
      : `+249${cleanPhone}`;

    setTimeout(() => {
      setIsSubmitting(false);
      onSendWhatsAppOtp({
        name: cleanName,
        phone: fullSudanPhone,
        city,
        accountType,
        password,
      });
    }, 600);
  };

  return (
    <div className="min-h-screen w-full bg-slate-950 flex flex-col justify-between p-4 max-w-md mx-auto relative overflow-y-auto">
      {/* Top Header with Back button */}
      <div className="flex items-center justify-between pt-2 pb-1">
        <button
          onClick={onNavigateToLogin}
          className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white transition flex items-center gap-1.5 text-xs cursor-pointer"
        >
          <ArrowRight className="w-4 h-4" />
          <span>الرجوع للدخول</span>
        </button>
        <span className="text-xs font-mono text-emerald-400">الخطوة 1 من 2</span>
      </div>

      {/* Modern Animated Phone above fields as requested */}
      <div className="flex flex-col items-center text-center my-3">
        <ModernAnimatedPhone size="md" showWaves={true} isFloating={true} className="mb-2" />
        <h2 className="text-2xl font-black text-white">إنشاء حساب جديد في mobiley</h2>
        <p className="text-xs text-slate-400 mt-0.5">
          انضم لأكبر سوق هواتف في السودان واعرض أجهزتك الآن
        </p>
      </div>

      {/* Signup Form Card */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl backdrop-blur-md mb-4">
        {errorMsg && (
          <div className="mb-4 p-3 bg-rose-500/15 border border-rose-500/30 rounded-xl flex items-center gap-2 text-rose-300 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5">
          {/* 1. Name Field with Hint */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              الاسم الكامل / اسم المتجر
            </label>
            <div className="relative flex items-center">
              <div className="absolute right-3 text-slate-400 pointer-events-none">
                <User className="w-4 h-4 text-emerald-400" />
              </div>
              <input
                type="text"
                placeholder="أدخل الاسم الكامل أو اسم المتجر"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-950/90 border border-slate-700/80 rounded-2xl py-2.5 pr-10 pl-3 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-sm transition"
              />
            </div>
            <span className="text-[10px] text-slate-500 mt-0.5 block">
              تلميح: الاسم الذي سيظهر للمشترين وزوار حسابك
            </span>
          </div>

          {/* 2. Phone Field with Fixed Sudan Code (+249) and Hint */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              رقم الهاتف (مفتاح السودان مثبت)
            </label>
            <div className="relative flex items-center">
              <div className="absolute right-3 text-slate-400 pointer-events-none">
                <Phone className="w-4 h-4 text-emerald-400" />
              </div>
              <input
                type="tel"
                dir="ltr"
                placeholder="أدخل رقم هاتفك (مثلاً: 912345678)"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                className="w-full bg-slate-950/90 border border-slate-700/80 rounded-2xl py-2.5 pr-10 pl-24 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-sm font-mono transition"
              />
              {/* Fixed country code badge */}
              <div className="absolute left-2 flex items-center gap-1 bg-emerald-950/60 border border-emerald-600/40 px-2 py-1 rounded-xl text-xs font-mono font-bold text-emerald-300">
                <span>🇸🇩</span>
                <span>+249</span>
              </div>
            </div>
            <span className="text-[10px] text-slate-500 mt-0.5 block">
              تلميح: سيصلك كود التحقق السريع عبر تطبيق WhatsApp
            </span>
          </div>

          {/* 3. Sudan City Selection Field with Hint */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              المدينة
            </label>
            <div className="relative flex items-center">
              <div className="absolute right-3 text-slate-400 pointer-events-none">
                <MapPin className="w-4 h-4 text-emerald-400" />
              </div>
              <select
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full bg-slate-950/90 border border-slate-700/80 rounded-2xl py-2.5 pr-10 pl-3 text-white focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-sm appearance-none transition cursor-pointer"
              >
                {SUDAN_CITIES.map((c) => (
                  <option key={c} value={c} className="bg-slate-900 text-white">
                    {c}
                  </option>
                ))}
              </select>
            </div>
            <span className="text-[10px] text-slate-500 mt-0.5 block">
              تلميح: حدد مدينتك في السودان لربطك بالمشترين القريبين منك
            </span>
          </div>

          {/* 5. Password & Confirm Password with Hints */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">كلمة السر</label>
              <div className="relative flex items-center">
                <div className="absolute right-3 text-slate-400 pointer-events-none">
                  <Lock className="w-4 h-4 text-emerald-400" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="أدخل كلمة السر (6 خانات على الأقل)"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-950/90 border border-slate-700/80 rounded-2xl py-2.5 pr-10 pl-8 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 text-xs transition"
                />
              </div>
              <span className="text-[10px] text-slate-500 mt-0.5 block">
                تلميح: لا تقل عن 6 أحرف أو أرقام
              </span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                إعادة كتابة كلمة السر
              </label>
              <div className="relative flex items-center">
                <div className="absolute right-3 text-slate-400 pointer-events-none">
                  <Lock className="w-4 h-4 text-emerald-400" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="أعد إدخال كلمة السر للتأكيد"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full bg-slate-950/90 border border-slate-700/80 rounded-2xl py-2.5 pr-10 pl-8 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 text-xs transition"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-2.5 text-slate-400 hover:text-white transition cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
              <span className="text-[10px] text-slate-500 mt-0.5 block">
                تلميح: مطابقة تماماً لكلمة السر الأولى
              </span>
            </div>
          </div>

          {/* 6. Send Verification Code via WhatsApp Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full mt-2 py-3.5 bg-gradient-to-r from-emerald-600 via-teal-600 to-green-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-2xl transition-all shadow-lg shadow-emerald-950/50 flex items-center justify-center gap-2 active:scale-[0.98] cursor-pointer"
          >
            {isSubmitting ? (
              <span className="text-sm">جارٍ إرسال كود الواتساب...</span>
            ) : (
              <>
                <Send className="w-4 h-4" />
                <span className="text-sm">إرسال كود التأكيد على واتساب</span>
              </>
            )}
          </button>
        </form>
      </div>

      {/* Bottom login link */}
      <div className="py-2 text-center">
        <button
          onClick={onNavigateToLogin}
          className="text-xs text-slate-400 hover:text-emerald-400 transition cursor-pointer"
        >
          لديك حساب بالفعل؟ <span className="text-emerald-400 font-bold underline">تسجيل الدخول</span>
        </button>
      </div>
    </div>
  );
};
