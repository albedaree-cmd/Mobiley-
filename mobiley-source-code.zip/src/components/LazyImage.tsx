import React, { useState, useEffect, useRef } from 'react';
import { Smartphone, Image as ImageIcon } from 'lucide-react';

interface LazyImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt: string;
  className?: string;
  containerClassName?: string;
  priority?: boolean;
  fallbackIcon?: 'phone' | 'image';
  showSkeleton?: boolean;
}

export const LazyImage: React.FC<LazyImageProps> = ({
  src,
  alt,
  className = '',
  containerClassName = '',
  priority = false,
  fallbackIcon = 'image',
  showSkeleton = true,
  onClick,
  ...restProps
}) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [isInView, setIsInView] = useState(priority);
  const containerRef = useRef<HTMLDivElement>(null);

  // IntersectionObserver to only load image when approaching viewport
  useEffect(() => {
    if (priority || isInView) return;

    if (typeof window === 'undefined' || !('IntersectionObserver' in window)) {
      setIsInView(true);
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIsInView(true);
            observer.disconnect();
          }
        });
      },
      {
        rootMargin: '250px 0px', // Preload when within 250px of viewport for seamless scrolling
        threshold: 0.01,
      }
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => {
      observer.disconnect();
    };
  }, [priority, isInView]);

  // Reset states if src changes
  useEffect(() => {
    setIsLoaded(false);
    setHasError(false);
  }, [src]);

  return (
    <div
      ref={containerRef}
      className={`relative overflow-hidden ${containerClassName}`}
      onClick={onClick}
    >
      {/* Animated Skeleton Shimmer Placeholder while loading */}
      {showSkeleton && !isLoaded && !hasError && (
        <div className="absolute inset-0 bg-slate-800/80 animate-pulse flex items-center justify-center">
          <div className="w-full h-full bg-gradient-to-r from-transparent via-slate-700/30 to-transparent -translate-x-full animate-[shimmer_1.5s_infinite]" />
          <div className="absolute inset-0 flex items-center justify-center opacity-30 text-slate-500">
            {fallbackIcon === 'phone' ? (
              <Smartphone className="w-8 h-8" />
            ) : (
              <ImageIcon className="w-8 h-8" />
            )}
          </div>
        </div>
      )}

      {/* Actual Image rendered when in view */}
      {isInView && !hasError && (
        <img
          src={src}
          alt={alt}
          loading={priority ? 'eager' : 'lazy'}
          decoding="async"
          onLoad={() => setIsLoaded(true)}
          onError={() => {
            setHasError(true);
            setIsLoaded(true);
          }}
          className={`transition-opacity duration-300 ease-out ${
            isLoaded ? 'opacity-100' : 'opacity-0'
          } ${className}`}
          {...restProps}
        />
      )}

      {/* Fallback state on error */}
      {hasError && (
        <div className="absolute inset-0 bg-slate-800/90 flex flex-col items-center justify-center text-slate-400 p-2">
          {fallbackIcon === 'phone' ? (
            <Smartphone className="w-8 h-8 mb-1 text-slate-500" />
          ) : (
            <ImageIcon className="w-8 h-8 mb-1 text-slate-500" />
          )}
          <span className="text-[10px] text-slate-500 text-center font-mono">تعذر تحميل الصورة</span>
        </div>
      )}
    </div>
  );
};
