import React from 'react';
import { motion } from 'motion/react';
import { Smartphone, Sparkles, Wifi, BatteryCharging } from 'lucide-react';

interface ModernAnimatedPhoneProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showWaves?: boolean;
  className?: string;
  isFloating?: boolean;
}

export const ModernAnimatedPhone: React.FC<ModernAnimatedPhoneProps> = ({
  size = 'lg',
  showWaves = true,
  className = '',
  isFloating = true,
}) => {
  const sizeMap = {
    sm: {
      outer: 'w-10 h-16 rounded-xl border-2 p-0.5',
      screen: 'rounded-lg',
      icon: 'w-4 h-4',
      notch: 'w-3 h-1',
    },
    md: {
      outer: 'w-16 h-28 rounded-2xl border-2 p-1',
      screen: 'rounded-xl',
      icon: 'w-6 h-6',
      notch: 'w-5 h-1.5',
    },
    lg: {
      outer: 'w-24 h-44 rounded-3xl border-[2.5px] p-1.5 shadow-2xl shadow-emerald-500/20',
      screen: 'rounded-2xl',
      icon: 'w-8 h-8',
      notch: 'w-8 h-2',
    },
    xl: {
      outer: 'w-32 h-60 rounded-[32px] border-4 p-2 shadow-2xl shadow-emerald-500/30',
      screen: 'rounded-[24px]',
      icon: 'w-12 h-12',
      notch: 'w-12 h-2.5',
    },
  };

  const current = sizeMap[size];

  return (
    <div className={`relative flex items-center justify-center ${className}`}>
      {/* Radar ripple waves */}
      {showWaves && (
        <>
          <motion.div
            initial={{ scale: 0.8, opacity: 0.7 }}
            animate={{ scale: [0.8, 1.4, 1.6], opacity: [0.7, 0.2, 0] }}
            transition={{
              duration: 2.4,
              repeat: Infinity,
              ease: 'easeOut',
            }}
            className="absolute inset-0 m-auto w-full h-full rounded-full bg-emerald-500/15 blur-md pointer-events-none"
          />
          <motion.div
            initial={{ scale: 0.9, opacity: 0.5 }}
            animate={{ scale: [0.9, 1.3, 1.5], opacity: [0.5, 0.15, 0] }}
            transition={{
              duration: 2.4,
              repeat: Infinity,
              delay: 0.8,
              ease: 'easeOut',
            }}
            className="absolute inset-0 m-auto w-full h-full rounded-full bg-cyan-500/15 blur-sm pointer-events-none"
          />
        </>
      )}

      {/* Floating Animated Smartphone Body */}
      <motion.div
        animate={
          isFloating
            ? {
                y: [-4, 5, -4],
                rotateZ: [-1.5, 1.5, -1.5],
              }
            : {}
        }
        transition={{
          duration: 3.5,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className={`relative bg-gradient-to-b from-slate-800 via-slate-900 to-slate-950 border-emerald-400/40 ${current.outer} flex flex-col items-center justify-between overflow-hidden backdrop-blur-md`}
      >
        {/* Dynamic Island / Top Notch */}
        <div
          className={`${current.notch} bg-black/90 rounded-full mx-auto my-1 flex items-center justify-center gap-1 shadow-sm`}
        >
          <div className="w-1 h-1 rounded-full bg-emerald-400/80" />
          <div className="w-0.5 h-0.5 rounded-full bg-slate-600" />
        </div>

        {/* Screen Display */}
        <div
          className={`w-full flex-1 bg-gradient-to-br from-slate-950 via-emerald-950/40 to-slate-900 ${current.screen} flex flex-col items-center justify-center relative overflow-hidden border border-emerald-500/10 p-2`}
        >
          {/* Subtle screen shine */}
          <div className="absolute -top-10 -right-10 w-24 h-24 bg-white/5 rounded-full blur-lg pointer-events-none" />

          {/* Screen Mini Header with Signal & Battery */}
          {size !== 'sm' && (
            <div className="w-full flex items-center justify-between text-[8px] text-emerald-400/70 px-1 mb-auto">
              <div className="flex items-center gap-0.5">
                <Wifi className="w-2.5 h-2.5" />
                <span className="font-mono">5G</span>
              </div>
              <BatteryCharging className="w-2.5 h-2.5 text-emerald-400" />
            </div>
          )}

          {/* Central Animated Phone/Logo element */}
          <motion.div
            animate={{
              scale: [1, 1.08, 1],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            className="relative my-auto flex flex-col items-center"
          >
            <div className="p-2 rounded-xl bg-gradient-to-tr from-emerald-500/20 to-teal-400/20 border border-emerald-400/30 text-emerald-400 shadow-md">
              <Smartphone className={current.icon} />
            </div>
            {size === 'xl' && (
              <span className="text-[10px] font-bold tracking-widest text-emerald-400/90 mt-1 uppercase">
                mobiley
              </span>
            )}
          </motion.div>

          {/* Floating tiny spark */}
          {size !== 'sm' && (
            <motion.div
              animate={{ opacity: [0.3, 1, 0.3], y: [-2, 2, -2] }}
              transition={{ duration: 1.8, repeat: Infinity }}
              className="absolute bottom-2 right-2 text-amber-300/80"
            >
              <Sparkles className="w-2.5 h-2.5" />
            </motion.div>
          )}

          {/* Home indicator bar at bottom */}
          <div className="w-8 h-1 bg-white/20 rounded-full mx-auto mt-auto mb-0.5" />
        </div>
      </motion.div>
    </div>
  );
};
