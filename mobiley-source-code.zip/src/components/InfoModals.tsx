import React from 'react';
import {
  X,
  Shield,
  Info,
  PhoneCall,
  Lock,
  Clock,
  Smartphone,
  Send,
  MessageSquare,
  CheckCircle2,
} from 'lucide-react';

interface InfoModalProps {
  type: 'privacy' | 'about' | 'contact' | null;
  onClose: () => void;
}

export const InfoModals: React.FC<InfoModalProps> = ({ type, onClose }) => {
  if (!type) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm select-none">
      <div className="w-full max-w-md bg-slate-900 border border-slate-700/90 rounded-3xl p-6 shadow-2xl relative my-auto max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* 1. Privacy Policy (سياسة الخصوصية) */}
        {type === 'privacy' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2.5 pb-3 border-b border-slate-800">
              <div className="w-10 h-10 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 flex items-center justify-center">
                <Shield className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-black text-white">سياسة الخصوصية والأمان</h3>
                <p className="text-xs text-emerald-400 font-mono">تطبيق mobiley - السودان</p>
              </div>
            </div>

            <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
              <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-2xl">
                <h4 className="font-bold text-white flex items-center gap-1.5 mb-1">
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>تأمين الحساب والتحقق عبر واتساب</span>
                </h4>
                <p>
                  نعتمد نظام التحقق المزدوج برمز OTP مرسل حصرياً عبر تطبيق WhatsApp لأرقام السودان (+249) لحماية المستخدمين من الحسابات الوهمية والاحتيال.
                </p>
              </div>

              <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-2xl">
                <h4 className="font-bold text-white flex items-center gap-1.5 mb-1">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  <span>حذف العروض التلقائي بعد أسبوع</span>
                </h4>
                <p>
                  يتم حذف عروض الهواتف تلقائياً بعد مرور 7 أيام كاملة من وقت النشر للحفاظ على حداثة الأسعار ومنع تداول أجهزة تم بيعها بالفعل.
                </p>
              </div>

              <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-2xl">
                <h4 className="font-bold text-white flex items-center gap-1.5 mb-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />
                  <span>تشفير وحماية الدردشة</span>
                </h4>
                <p>
                  كافة الرسائل والمحادثات داخل التطبيق مشفرة ومحمية ببروتوكولات أمان متقدمة لضمان خصوصية التواصل التام بين المشتري والبائع.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* 2. About Us (من نحن) */}
        {type === 'about' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2.5 pb-3 border-b border-slate-800">
              <div className="w-10 h-10 rounded-2xl bg-blue-500/15 border border-blue-500/30 text-blue-400 flex items-center justify-center">
                <Info className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-black text-white">من نحن - mobiley</h3>
                <p className="text-xs text-blue-400">سوق ومجتمع الهواتف الذكية</p>
              </div>
            </div>

            <div className="text-xs text-slate-300 space-y-3 leading-relaxed">
              <p>
                <strong className="text-white">mobiley</strong> هو التطبيق السوداني المتخصص
                الذي يربط مقتني وتجار الهواتف الذكية في جميع مدن السودان لعرض وطلب وشراء الأجهزة بكل سهولة وسرعة.
              </p>

              <p className="text-slate-400">
                صُمم التطبيق ليكون خفيفاً وسريعاً جداً في استهلاك البيانات، ليعمل بسلاسة فائقة حتى مع
                سرعات الإنترنت الضعيفة.
              </p>
            </div>
          </div>
        )}

        {/* 3. Contact Us (تواصل معنا) */}
        {type === 'contact' && (
          <div className="space-y-4">
            <div className="flex items-center gap-2.5 pb-3 border-b border-slate-800">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-400 flex items-center justify-center">
                <PhoneCall className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-black text-white">تواصل مع إدارة mobiley</h3>
                <p className="text-xs text-amber-400">دعم فني واستفسارات على مدار الساعة</p>
              </div>
            </div>

            <div className="space-y-2.5 text-xs text-slate-300">
              {/* WhatsApp Support */}
              <a
                href="https://wa.me/249912345678"
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-between p-3.5 bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-500/40 rounded-2xl transition group"
              >
                <div className="flex items-center gap-3">
                  <MessageSquare className="w-5 h-5 text-emerald-400" />
                  <div className="text-right">
                    <p className="font-bold text-white group-hover:text-emerald-300">
                      دعم واتساب الفوري
                    </p>
                    <p className="text-[11px] text-emerald-400 font-mono" dir="ltr">
                      +249 91 234 5678
                    </p>
                  </div>
                </div>
                <span className="text-[10px] bg-emerald-600 text-white px-2 py-1 rounded-lg font-semibold">
                  محادثة
                </span>
              </a>

              {/* Direct Phone Support */}
              <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-2xl flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <PhoneCall className="w-5 h-5 text-blue-400" />
                  <div className="text-right">
                    <p className="font-bold text-white">الخط الساخن للمتاجر والبترينات</p>
                    <p className="text-[11px] text-slate-400 font-mono" dir="ltr">
                      +249 12 345 6789
                    </p>
                  </div>
                </div>
              </div>

              {/* Location */}
              <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-2xl text-[11px] text-slate-400">
                📍 المقر: الخرطوم - السوق العربي / فرع بورتسودان - شارع الميناء
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
