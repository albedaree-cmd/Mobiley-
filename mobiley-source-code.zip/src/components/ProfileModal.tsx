import React, { useState } from 'react';
import {
  X,
  MapPin,
  Star,
  MessageCircle,
  Phone,
  ShieldCheck,
  Calendar,
  Sparkles,
  Smartphone,
  CheckCircle,
  Maximize2,
} from 'lucide-react';
import { User, PhoneListing } from '../types';
import { DatabaseService } from '../services/supabaseService';
import { LazyImage } from './LazyImage';
import { FullscreenImageViewer } from './FullscreenImageViewer';
import { MOBILEY_OFFICIAL_COVER } from '../assets/mobileyCover';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
  userListings: PhoneListing[];
  isCurrentUser: boolean;
  onOpenChatWithUser: (user: User, listing?: PhoneListing) => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  user: initialUser,
  userListings,
  isCurrentUser,
  onOpenChatWithUser,
}) => {
  const [user, setUser] = useState<User>(initialUser);
  const [hoverRating, setHoverRating] = useState<number | null>(null);
  const [hasRated, setHasRated] = useState(false);
  const [ratingSuccessMsg, setRatingSuccessMsg] = useState('');
  const [isUserActive, setIsUserActive] = useState(false);
  const [fullscreenViewer, setFullscreenViewer] = useState<{
    isOpen: boolean;
    images: string[];
    title: string;
  }>({
    isOpen: false,
    images: [],
    title: '',
  });

  if (!isOpen) return null;

  const handleRate = (stars: number) => {
    if (isCurrentUser) {
      setRatingSuccessMsg('لا يمكنك تقييم حسابك الشخصي');
      return;
    }
    if (hasRated) {
      setRatingSuccessMsg('لقد قمت بتقييم هذا الحساب مسبقاً، شكراً لك!');
      return;
    }

    const updated = DatabaseService.rateUser(user.id, stars);
    if (updated) {
      setUser(updated);
      setHasRated(true);
      setRatingSuccessMsg(`شكراً! تم تسجيل تقييمك (${stars} نجوم)`);
      setTimeout(() => setRatingSuccessMsg(''), 3000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-sm overflow-y-auto select-none">
      <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-3xl overflow-hidden shadow-2xl relative my-auto max-h-[92vh] flex flex-col">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 z-20 w-8 h-8 rounded-full bg-black/60 hover:bg-black/80 text-white flex items-center justify-center backdrop-blur-sm transition cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="overflow-y-auto flex-1">
          {/* 1. Cover Photo with Mobiley brand visual identity (ثابتة على كل الحسابات) */}
          <div
            onClick={() =>
              setFullscreenViewer({
                isOpen: true,
                images: [MOBILEY_OFFICIAL_COVER],
                title: 'غلاف Mobiley الرسمي',
              })
            }
            className="relative h-36 w-full bg-slate-900 cursor-pointer group overflow-hidden"
            title="اضغط لعرض صورة الغلاف بشاشة كاملة"
          >
            <img
              src={MOBILEY_OFFICIAL_COVER}
              alt="غلاف Mobiley الرسمي"
              className="w-full h-full object-cover transition duration-300 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-black/30 pointer-events-none" />
            <div className="absolute bottom-2 left-2 px-2 py-1 rounded-lg bg-black/60 backdrop-blur-sm text-[10px] text-white flex items-center gap-1 opacity-0 group-hover:opacity-100 transition">
              <Maximize2 className="w-3 h-3" />
              <span>تكبير الغلاف</span>
            </div>
          </div>

          {/* 2. Centered Circular Profile Picture (تفتح بشاشة كاملة عند الضغط عليها) */}
          <div className="relative -mt-16 flex flex-col items-center px-6 text-center">
            <div
              onClick={() =>
                setFullscreenViewer({
                  isOpen: true,
                  images: [user.avatar],
                  title: user.name,
                })
              }
              className="relative cursor-pointer group"
              title="اضغط لعرض الصورة الشخصية بشاشة كاملة"
            >
              <LazyImage
                src={user.avatar}
                alt={user.name}
                containerClassName="w-24 h-24 rounded-full border-4 border-slate-900 shadow-xl bg-slate-800 overflow-hidden group-hover:border-emerald-500 transition duration-300"
                className="w-full h-full object-cover group-hover:scale-110 transition duration-300"
                priority={true}
              />
              <span className="absolute bottom-1 right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-slate-900 z-10" />
              <div className="absolute inset-0 rounded-full bg-black/40 opacity-0 group-hover:opacity-100 transition flex items-center justify-center text-white">
                <Maximize2 className="w-5 h-5 drop-shadow-md" />
              </div>
            </div>

            {/* 3. User Name, Verified Badge & Online Indicator */}
            <div className="mt-2.5 flex items-center gap-2">
              <h2 className="text-xl font-black text-white">{user.name}</h2>
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />

              {/* مؤشر حالة 'متصل' (نقطة خضراء) بجانب اسم المستخدم */}
              <div
                onClick={() => setIsUserActive((prev) => !prev)}
                onMouseEnter={() => setIsUserActive(true)}
                onMouseLeave={() => setIsUserActive(false)}
                className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/25 text-emerald-400 text-[10px] font-medium transition-all duration-300 select-none cursor-pointer"
                title={isUserActive ? 'المستخدم متصل الآن' : 'متصل'}
              >
                <span className="relative flex h-2 w-2 shrink-0">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
                </span>
                {/* يظهر النص 'متصل' فقط عند نشاط المستخدم */}
                <span
                  className={`transition-all duration-300 overflow-hidden whitespace-nowrap ${
                    isUserActive
                      ? 'max-w-[48px] opacity-100'
                      : 'max-w-0 opacity-0'
                  }`}
                >
                  متصل
                </span>
              </div>
            </div>

            {/* City Name (اسم المدينة) */}
            <div className="mt-1.5 flex items-center justify-center">
              <span className="text-xs text-slate-300 flex items-center gap-1 bg-slate-800/80 px-3 py-1 rounded-full border border-slate-700/60">
                <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                <span>{user.city}</span>
              </span>
            </div>

            {/* Bio / Description if available (excluding any registration sentence) */}
            {user.bio && !user.bio.includes('مسجل في') && !user.bio.includes('متجر مسجل') && (
              <p className="text-xs text-slate-300 mt-2.5 leading-relaxed bg-slate-950/60 p-2.5 rounded-2xl border border-slate-800 max-w-sm">
                {user.bio}
              </p>
            )}

            {/* 6. Visitor Interactive Star Ratings (نجوم تقييم من قبل زوار البروفايل) */}
            <div className="w-full mt-4 p-3.5 bg-slate-950/80 border border-slate-800 rounded-2xl flex flex-col items-center">
              <div className="flex items-center gap-2 mb-1.5">
                <span className="text-lg font-black text-amber-400 font-mono">
                  {user.rating}
                </span>
                <div className="flex items-center gap-1 text-amber-400">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onMouseEnter={() => !hasRated && setHoverRating(star)}
                      onMouseLeave={() => setHoverRating(null)}
                      onClick={() => handleRate(star)}
                      className="transition transform hover:scale-125 cursor-pointer"
                      title={`تقييم بـ ${star} نجوم`}
                    >
                      <Star
                        className={`w-5 h-5 ${
                          (hoverRating || Math.round(user.rating)) >= star
                            ? 'fill-amber-400 text-amber-400'
                            : 'text-slate-600'
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              <p className="text-[11px] text-slate-400">
                تقييمات زوار البروفايل: ({user.ratingsCount} تقييم موثق)
              </p>

              {ratingSuccessMsg && (
                <span className="text-xs text-emerald-400 font-medium mt-1 animate-fade-in">
                  {ratingSuccessMsg}
                </span>
              )}
            </div>

            {/* 7. Action Button: Chat Button (زر شات) */}
            {!isCurrentUser && (
              <div className="w-full mt-3.5 flex gap-2">
                <button
                  onClick={() => onOpenChatWithUser(user)}
                  className="flex-1 py-3 bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-bold text-xs rounded-2xl transition shadow-lg shadow-emerald-950/40 flex items-center justify-center gap-2 active:scale-95 cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>دردشة</span>
                </button>
              </div>
            )}

            {/* All Phone Listings by this User */}
            <div className="w-full mt-5 text-right border-t border-slate-800 pt-3.5">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-sm text-white flex items-center gap-1.5">
                  <Smartphone className="w-4 h-4 text-emerald-400" />
                  <span>عروض الهواتف</span>
                </h3>
                <span className="text-xs font-mono text-emerald-400 bg-slate-800 px-2 py-0.5 rounded-full">
                  {userListings.length}
                </span>
              </div>

              {userListings.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-500 bg-slate-950/50 rounded-2xl border border-slate-800">
                  لا توجد عروض هواتف حالياً لهذا الحساب
                </div>
              ) : (
                <div className="space-y-3">
                  {userListings.map((item) => (
                    <div
                      key={item.id}
                      className="p-3 bg-slate-950 border border-slate-800 rounded-2xl flex flex-col gap-2.5 text-right"
                    >
                      <div className="flex items-center gap-3">
                        <LazyImage
                          src={item.images[0]}
                          alt={item.title}
                          containerClassName="w-16 h-16 rounded-xl border border-slate-800 shrink-0"
                          className="w-full h-full object-cover"
                          fallbackIcon="phone"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-bold text-white truncate">{item.title}</p>
                          <p className="text-xs text-emerald-400 font-medium">{item.model}</p>
                          <div className="flex items-center justify-between mt-1">
                            <span className="text-sm font-black text-emerald-400 font-mono">
                              {item.price.toLocaleString()} {item.currency}
                            </span>
                            <span className="text-[10px] text-slate-400 bg-slate-900 px-2 py-0.5 rounded-md border border-slate-800">
                              {item.city}
                            </span>
                          </div>
                        </div>
                      </div>

                      {item.notes && (
                        <p className="text-[11px] text-slate-400 bg-slate-900/60 p-2 rounded-xl border border-slate-800/80">
                          {item.notes}
                        </p>
                      )}

                      {!isCurrentUser && (
                        <button
                          onClick={() => onOpenChatWithUser(user, item)}
                          className="w-full py-2 bg-emerald-600/90 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 active:scale-95 cursor-pointer"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>دردشة</span>
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="mt-4 mb-2 text-[10px] text-slate-500 flex items-center justify-center gap-1">
              <Calendar className="w-3 h-3" />
              <span>عضو في mobiley منذ {user.joinedDate}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Fullscreen Image Viewer Modal */}
      <FullscreenImageViewer
        isOpen={fullscreenViewer.isOpen}
        images={fullscreenViewer.images}
        title={fullscreenViewer.title}
        onClose={() =>
          setFullscreenViewer({ isOpen: false, images: [], title: '' })
        }
      />
    </div>
  );
};
