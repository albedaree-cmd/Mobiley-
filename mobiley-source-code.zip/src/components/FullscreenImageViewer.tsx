import React, { useState, useEffect, useRef } from 'react';
import { X, ChevronLeft, ChevronRight, ZoomIn } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface FullscreenImageViewerProps {
  isOpen: boolean;
  images: string[];
  initialIndex?: number;
  title?: string;
  onClose: () => void;
}

export const FullscreenImageViewer: React.FC<FullscreenImageViewerProps> = ({
  isOpen,
  images = [],
  initialIndex = 0,
  title,
  onClose,
}) => {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const touchStartX = useRef<number | null>(null);
  const touchDeltaX = useRef<number>(0);
  const mouseStartX = useRef<number | null>(null);
  const [isSwiping, setIsSwiping] = useState(false);

  // Sync current index and lock body scroll on open
  useEffect(() => {
    if (isOpen) {
      setCurrentIndex(initialIndex);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen, initialIndex]);

  const goToNext = () => {
    if (!images || images.length <= 1) return;
    setCurrentIndex((prev) => (prev < images.length - 1 ? prev + 1 : 0));
  };

  const goToPrev = () => {
    if (!images || images.length <= 1) return;
    setCurrentIndex((prev) => (prev > 0 ? prev - 1 : images.length - 1));
  };

  // Keyboard navigation (Arrow keys + Esc)
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'ArrowRight') {
        goToPrev();
      } else if (e.key === 'ArrowLeft') {
        goToNext();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, currentIndex, images?.length]);

  // Touch Swipe handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      touchStartX.current = e.touches[0].clientX;
      touchDeltaX.current = 0;
      setIsSwiping(true);
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (touchStartX.current !== null && e.touches.length === 1) {
      touchDeltaX.current = e.touches[0].clientX - touchStartX.current;
    }
  };

  const handleTouchEnd = () => {
    if (touchStartX.current !== null) {
      const delta = touchDeltaX.current;
      // If swiped significantly
      if (images && images.length > 1 && delta > 50) {
        goToPrev();
      } else if (images && images.length > 1 && delta < -50) {
        goToNext();
      } else if (Math.abs(delta) < 12) {
        // It was a tap! Close and return to normal mode
        onClose();
      }
      touchStartX.current = null;
      touchDeltaX.current = 0;
      setIsSwiping(false);
    }
  };

  // Mouse Drag handlers for testing on desktop
  const handleMouseDown = (e: React.MouseEvent) => {
    mouseStartX.current = e.clientX;
  };

  const handleMouseUp = (e: React.MouseEvent) => {
    if (mouseStartX.current !== null) {
      const delta = e.clientX - mouseStartX.current;
      if (images && images.length > 1 && delta > 60) {
        goToPrev();
      } else if (images && images.length > 1 && delta < -60) {
        goToNext();
      } else if (Math.abs(delta) < 8) {
        // It was a click! Close and return to normal mode
        onClose();
      }
      mouseStartX.current = null;
    }
  };

  // Early return ONLY after all hooks have been unconditionally registered
  if (!isOpen || !images || images.length === 0) return null;

  return (
    <div
      className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-lg flex flex-col justify-between select-none animate-in fade-in duration-200 cursor-pointer"
      onClick={onClose}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onMouseDown={handleMouseDown}
      onMouseUp={handleMouseUp}
    >
      {/* Top Header Bar */}
      <div
        className="w-full flex items-center justify-between p-4 z-20 bg-gradient-to-b from-black/80 to-transparent pointer-events-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onClose}
            className="w-10 h-10 rounded-full bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-white flex items-center justify-center transition cursor-pointer shadow-lg active:scale-95"
            title="إغلاق والرجوع للوضع الطبيعي (Esc)"
          >
            <X className="w-5 h-5" />
          </button>
          {title && (
            <p className="text-white font-bold text-sm truncate max-w-[200px] sm:max-w-md">
              {title}
            </p>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-1.5 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold transition cursor-pointer"
          >
            رجوع
          </button>
          {images.length > 1 && (
            <div className="px-3 py-1 rounded-full bg-slate-900/80 border border-slate-700 text-slate-200 text-xs font-mono font-bold shadow-md">
              {currentIndex + 1} / {images.length}
            </div>
          )}
        </div>
      </div>

      {/* Center Image Container */}
      <div className="relative flex-1 flex items-center justify-center p-2 sm:p-6 overflow-hidden">
        {/* Navigation Button: Right */}
        {images.length > 1 && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              goToPrev();
            }}
            className="absolute right-3 top-1/2 -translate-y-1/2 z-30 w-11 h-11 rounded-full bg-slate-900/80 hover:bg-emerald-600 border border-slate-700 hover:border-emerald-400 text-white flex items-center justify-center transition backdrop-blur-md shadow-xl active:scale-90 cursor-pointer"
            title="الصورة السابقة"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        )}

        {/* Animated Active Image */}
        <div className="relative max-w-full max-h-full flex items-center justify-center">
          <AnimatePresence mode="wait">
            <motion.img
              key={images[currentIndex]}
              src={images[currentIndex]}
              alt={`عرض ${currentIndex + 1}`}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.2 }}
              onClick={(e) => {
                e.stopPropagation();
                onClose();
              }}
              className="max-h-[82vh] max-w-[95vw] md:max-w-[85vw] object-contain rounded-2xl shadow-2xl cursor-pointer hover:opacity-95 transition-opacity"
              title="اضغط على الصورة للرجوع للوضع الطبيعي"
              draggable={false}
            />
          </AnimatePresence>
        </div>

        {/* Navigation Button: Left */}
        {images.length > 1 && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              goToNext();
            }}
            className="absolute left-3 top-1/2 -translate-y-1/2 z-30 w-11 h-11 rounded-full bg-slate-900/80 hover:bg-emerald-600 border border-slate-700 hover:border-emerald-400 text-white flex items-center justify-center transition backdrop-blur-md shadow-xl active:scale-90 cursor-pointer"
            title="الصورة التالية"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
        )}
      </div>

      {/* Bottom Thumbnail Bar & Swipe Hint */}
      <div
        className="w-full p-4 z-20 flex flex-col items-center gap-2 bg-gradient-to-t from-black/90 via-black/50 to-transparent"
        onClick={(e) => e.stopPropagation()}
      >
        {images.length > 1 && (
          <div className="flex items-center gap-2 max-w-full overflow-x-auto py-1 px-2 scrollbar-none">
            {images.map((img, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentIndex(idx)}
                className={`relative w-12 h-12 rounded-xl overflow-hidden border-2 transition cursor-pointer shrink-0 ${
                  currentIndex === idx
                    ? 'border-emerald-400 scale-105 shadow-md shadow-emerald-500/40'
                    : 'border-slate-700 opacity-60 hover:opacity-100'
                }`}
              >
                <img
                  src={img}
                  alt={`مصغرة ${idx + 1}`}
                  className="w-full h-full object-cover"
                />
              </button>
            ))}
          </div>
        )}

        {images.length > 1 && (
          <p className="text-[11px] text-slate-400 font-medium select-none">
            اسحب يميناً أو يساراً للتنقل بين الصور
          </p>
        )}
      </div>
    </div>
  );
};
