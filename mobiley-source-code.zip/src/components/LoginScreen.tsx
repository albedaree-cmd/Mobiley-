import React, { useState, useEffect } from 'react';
import {
  User as UserIcon,
  Phone,
  MapPin,
  AlertCircle,
} from 'lucide-react';
import { ModernAnimatedPhone } from './ModernAnimatedPhone';
import { DatabaseService, sanitizeInput } from '../services/supabaseService';
import { SUDAN_CITIES } from '../data/sudanData';
import { User, AccountType } from '../types';

interface LoginScreenProps {
  onLoginSuccess: (user: User) => void;
  onSendWhatsAppOtp: (userData: {
    name: string;
    phone: string;
    city: string;
    accountType: AccountType;
    autoLogin: boolean;
  }) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  onLoginSuccess,
  onSendWhatsAppOtp,
}) => {
  // Read any previously saved data for automatic pre-fill
  const savedData = DatabaseService.getSavedLoginData();

  const [name, setName] = useState(savedData?.name || '');
  const [phoneNumber, setPhoneNumber] = useState(
    savedData?.phone ? savedData.phone.replace('+249', '').replace(/^0/, '') : ''
  );
  const [city, setCity] = useState(savedData?.city || SUDAN_CITIES[0]);
  const autoLogin = true; // يتم حفظ البيانات تلقائياً دائماً في الخلفية بدون الحاجة لظهور النص
  const [errorMsg, setErrorMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // إذا كان المستخدم مسجل مسبقاً، يدخل مباشرة دون إظهار شاشة الدخول أو البانر
  const existingUser = savedData?.phone ? DatabaseService.findUserByPhone(savedData.phone) : null;

  useEffect(() => {
    if (existingUser) {
      DatabaseService.setCurrentUser(existingUser);
      onLoginSuccess(existingUser);
    }
  }, [existingUser, onLoginSuccess]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const cleanName = sanitizeInput(name);
    if (!cleanName || cleanName.trim().length < 2) {
      setErrorMsg('يرجى إدخال اسمك الكريم أو اسم المتجر');
      return;
    }

    const cleanPhone = sanitizeInput(phoneNumber).replace(/\s+/g, '');
    if (!cleanPhone || cleanPhone.length < 9) {
      setErrorMsg('يرجى إدخال رقم هاتف سوداني صحيح مكون من 9 أرقام (مثال: 912345678)');
      return;
    }

    if (!city) {
      setErrorMsg('يرجى اختيار المدينة');
      return;
    }

    setIsLoading(true);

    const fullSudanPhone = cleanPhone.startsWith('+249')
      ? cleanPhone
      : cleanPhone.startsWith('0')
      ? `+249${cleanPhone.slice(1)}`
      : `+249${cleanPhone}`;

    // Save login credentials silently for future auto-login
    DatabaseService.setSavedLoginData({
      name: cleanName,
      phone: fullSudanPhone,
      city,
      autoLogin: true,
    });

    setTimeout(() => {
      setIsLoading(false);
      onSendWhatsAppOtp({
        name: cleanName,
        phone: fullSudanPhone,
        city,
        accountType: 'individual',
        autoLogin: true,
      });
    }, 500);
  };

  // إذا وجد مستخدم سابق يتم تحويله فوراً
  if (existingUser) {
    return null;
  }

  return (
    <div className="min-h-screen w-full bg-slate-950 flex flex-col justify-center p-4 max-w-md mx-auto relative overflow-y-auto">
      {/* Top Header */}
      <div className="pt-2 pb-2 flex flex-col items-center text-center">
        <ModernAnimatedPhone size="md" showWaves={false} isFloating={true} className="mb-2" />

        <h2 className="text-3xl font-black text-white tracking-tight font-['Plus_Jakarta_Sans',sans-serif]">
          mobiley
        </h2>
        <p className="text-sm text-emerald-400 font-semibold mt-1">سوق الهواتف الذكية في السودان</p>
      </div>

      {/* Main Card: Name, Phone, City, and Create Account Button */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl backdrop-blur-md my-2">
        {errorMsg && (
          <div className="mb-4 p-3 bg-rose-500/15 border border-rose-500/30 rounded-xl flex items-center gap-2 text-rose-300 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5">
          {/* 1. حقل الاسم */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              الاسم الكامل / اسم النشاط
            </label>
            <div className="relative flex items-center">
              <div className="absolute right-3 text-slate-400 pointer-events-none">
                <UserIcon className="w-4 h-4 text-emerald-400" />
              </div>
              <input
                type="text"
                placeholder="أدخل اسمك أو اسم المعرض"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-950/90 border border-slate-700/80 rounded-2xl py-3 pr-10 pl-3 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-sm transition"
              />
            </div>
          </div>

          {/* 2. حقل رقم الهاتف مع كود السودان */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              رقم الهاتف (واتساب)
            </label>
            <div className="relative flex items-center">
              <div className="absolute right-3 flex items-center gap-1.5 text-slate-400 pointer-events-none">
                <Phone className="w-4 h-4 text-emerald-400" />
              </div>
              <input
                type="tel"
                dir="ltr"
                placeholder="9XXXXXXXX"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                className="w-full bg-slate-950/90 border border-slate-700/80 rounded-2xl py-3 pr-10 pl-24 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-sm font-mono transition"
              />
              <div className="absolute left-2.5 flex items-center gap-1 bg-slate-800/90 border border-slate-700 px-2.5 py-1 rounded-xl text-xs font-mono text-emerald-400 select-none">
                <span>🇸🇩</span>
                <span>+249</span>
              </div>
            </div>
            <span className="text-[10px] text-slate-500 mt-1 block">
              سيتم إرسال كود التحقق مباشرة إلى رقم الواتساب هذا
            </span>
          </div>

          {/* 3. اختيار المدينة */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              اختيار المدينة
            </label>
            <div className="relative flex items-center">
              <div className="absolute right-3 text-slate-400 pointer-events-none">
                <MapPin className="w-4 h-4 text-emerald-400" />
              </div>
              <select
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full bg-slate-950/90 border border-slate-700/80 rounded-2xl py-3 pr-10 pl-3 text-white focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-sm transition appearance-none cursor-pointer"
              >
                {SUDAN_CITIES.map((c) => (
                  <option key={c} value={c} className="bg-slate-900 text-white">
                    {c}
                  </option>
                ))}
              </select>
              <div className="absolute left-3 text-slate-400 pointer-events-none text-xs">
                ▼
              </div>
            </div>
          </div>

          {/* 4. زر إنشاء حساب مع إرسال الكود على واتساب */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-bold rounded-2xl transition-all shadow-lg shadow-emerald-950/50 flex items-center justify-center active:scale-[0.98] cursor-pointer mt-4"
          >
            {isLoading ? (
              <span className="text-sm">جارٍ الإرسال إلى واتساب...</span>
            ) : (
              <span className="text-sm font-black">إنشاء حساب</span>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
