import React from 'react';
import { WifiOff, RefreshCw, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface NetworkOfflineDialogProps {
  isOpen: boolean;
  onRetry: () => void;
  isRetrying?: boolean;
}

export const NetworkOfflineDialog: React.FC<NetworkOfflineDialogProps> = ({
  isOpen,
  onRetry,
  isRetrying = false,
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="w-full max-w-sm bg-slate-900 border border-slate-700/80 rounded-2xl p-6 shadow-2xl text-center relative overflow-hidden"
          >
            {/* Top decorative aura */}
            <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-32 h-32 bg-rose-500/20 rounded-full blur-2xl pointer-events-none" />

            {/* Offline Icon Container resembling Facebook style */}
            <div className="mx-auto w-16 h-16 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center mb-4 text-rose-400 shadow-inner">
              <WifiOff className="w-8 h-8 animate-pulse" />
            </div>

            <h3 className="text-xl font-bold text-white mb-2">
              لا يوجد اتصال بالإنترنت
            </h3>
            
            <p className="text-slate-300 text-sm leading-relaxed mb-6">
              يبدو أنك غير متصل بالشبكة. يرجى التحقق من اتصال شبكة Wi-Fi أو بيانات الهاتف والمحاولة مرة أخرى.
            </p>

            <div className="flex flex-col gap-2.5">
              <button
                onClick={onRetry}
                disabled={isRetrying}
                className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-500 active:scale-[0.98] disabled:opacity-60 text-white font-semibold rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/40 cursor-pointer"
              >
                <RefreshCw className={`w-4 h-4 ${isRetrying ? 'animate-spin' : ''}`} />
                <span>{isRetrying ? 'جارٍ فحص الاتصال...' : 'إعادة المحاولة'}</span>
              </button>
            </div>

            <div className="mt-4 flex items-center justify-center gap-1.5 text-xs text-slate-400">
              <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
              <span>mobiley يتطلب اتصالاً نشطاً لتحديث الأسعار</span>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
