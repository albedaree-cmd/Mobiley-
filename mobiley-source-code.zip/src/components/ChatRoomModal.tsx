import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowRight,
  Send,
  CheckCheck,
  Smartphone,
  Sparkles,
  Clock,
} from 'lucide-react';
import { ChatMessage, User as UserType, PhoneListing } from '../types';
import { DatabaseService, sanitizeInput } from '../services/supabaseService';
import { playRoyaltyFreeTone } from '../services/notificationSound';
import { LazyImage } from './LazyImage';

interface ChatRoomModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBackToConversations?: () => void;
  currentUser: UserType;
  seller: {
    id: string;
    name: string;
    avatar: string;
    phone: string;
    accountType?: any;
    city?: string;
  };
  listingContext?: PhoneListing | null;
}

export const ChatRoomModal: React.FC<ChatRoomModalProps> = ({
  isOpen,
  onClose,
  onBackToConversations,
  currentUser,
  seller,
  listingContext,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isUserActive, setIsUserActive] = useState(true);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const activityTimerRef = useRef<NodeJS.Timeout | null>(null);

  const triggerActivity = () => {
    setIsUserActive(true);
    if (activityTimerRef.current) clearTimeout(activityTimerRef.current);
    activityTimerRef.current = setTimeout(() => {
      setIsUserActive(false);
    }, 4000);
  };

  useEffect(() => {
    if (!isOpen) return;

    // Mark messages from seller as read
    DatabaseService.markConversationAsRead(seller.id, currentUser.id);

    // Show 'متصل' text briefly on opening, then collapse to green dot
    triggerActivity();

    // Load initial messages
    const existing = DatabaseService.getMessages(seller.id, currentUser.id);
    if (existing.length > 0) {
      setMessages(existing);
    } else {
      // Seed an initial welcoming message from seller
      const defaultMsg: ChatMessage = {
        id: 'seed-1',
        senderId: seller.id,
        receiverId: currentUser.id,
        text: `مرحباً بك! أنا ${seller.name}، بخصوص ${
          listingContext?.title || 'الهاتف المعروض'
        }، هل تود الاستفسار عن أي تفاصيل أو حجز موعد للمعاينة؟`,
        timestamp: Date.now() - 60000,
        read: true,
      };
      setMessages([defaultMsg]);
    }

    return () => {
      if (activityTimerRef.current) clearTimeout(activityTimerRef.current);
    };
  }, [isOpen, seller.id, currentUser.id, listingContext?.title]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  if (!isOpen) return null;

  const handleSendText = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const text = sanitizeInput(inputText);
    if (!text.trim()) return;

    triggerActivity();

    const newMsg = DatabaseService.sendMessage({
      senderId: currentUser.id,
      receiverId: seller.id,
      text,
      listingId: listingContext?.id,
      listingTitle: listingContext?.title,
    });

    setMessages((prev) => [...prev, newMsg]);
    setInputText('');

    // Simulate seller smart reply
    setTimeout(() => {
      triggerActivity();
      const replies = [
        'أهلاً وسهلاً، الجهاز بحالة ممتازة وخالي تماماً من المشاكل ومعاه الفاتورة والضمان.',
        'تمام يا غالي، متواجد في المحل طوال اليوم وممكن تشرفنا تعاين الجهاز على راحتك.',
        'السعر نهائي يا أخي ومناسب جداً لحالة النظافة، لكن ممكن نراعيك في حماية شاشة وكفر هدية!',
        'تسلم، أنا جاهز لأي استفسار أو لترتيب موعد للمعاينة.',
      ];
      const randomReply = replies[Math.floor(Math.random() * replies.length)];
      const sellerReply = DatabaseService.sendMessage({
        senderId: seller.id,
        receiverId: currentUser.id,
        text: randomReply,
      });
      playRoyaltyFreeTone('message');
      setMessages((prev) => [...prev, sellerReply]);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-2 sm:p-4 select-none">
      <div className="w-full max-w-md h-[94vh] bg-slate-900 border border-slate-700 rounded-3xl flex flex-col overflow-hidden shadow-2xl relative">
        {/* Chat Header */}
        <header className="p-3.5 bg-slate-800/90 border-b border-slate-700 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <button
              onClick={onBackToConversations || onClose}
              className="p-2 rounded-xl bg-slate-700/60 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer flex items-center gap-1.5"
              title={onBackToConversations ? 'العودة لقائمة المحادثات' : 'إغلاق الدردشة'}
            >
              <ArrowRight className="w-4 h-4" />
              {onBackToConversations && (
                <span className="text-[11px] font-medium hidden sm:inline">المحادثات</span>
              )}
            </button>

            <div className="relative">
              <LazyImage
                src={seller.avatar}
                alt={seller.name}
                containerClassName="w-10 h-10 rounded-full border-2 border-emerald-500 overflow-hidden"
                className="w-full h-full object-cover"
                priority={true}
              />
              <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full border-2 border-slate-800 z-10" />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm text-white">{seller.name}</h3>

                {/* مؤشر حالة 'متصل' (نقطة خضراء) بجانب اسم المستخدم */}
                <div
                  onClick={triggerActivity}
                  onMouseEnter={() => setIsUserActive(true)}
                  onMouseLeave={() => setIsUserActive(false)}
                  className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/25 text-emerald-400 text-[10px] font-medium transition-all duration-300 select-none cursor-pointer"
                  title={isUserActive ? 'المستخدم متصل الآن' : 'متصل'}
                >
                  <span className="relative flex h-2 w-2 shrink-0">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
                  </span>
                  {/* يظهر النص 'متصل' فقط عند نشاط المستخدم */}
                  <span
                    className={`transition-all duration-300 overflow-hidden whitespace-nowrap ${
                      isUserActive
                        ? 'max-w-[48px] opacity-100'
                        : 'max-w-0 opacity-0'
                    }`}
                  >
                    متصل
                  </span>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Listing Context Banner (if arrived from an ad) */}
        {listingContext && (
          <div className="bg-slate-950/80 border-b border-slate-800 p-2.5 px-4 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2.5">
              <LazyImage
                src={listingContext.images[0]}
                alt={listingContext.title}
                containerClassName="w-9 h-9 rounded-xl border border-slate-700 overflow-hidden shrink-0"
                className="w-full h-full object-cover"
                fallbackIcon="phone"
                priority={true}
              />
              <div>
                <p className="text-xs font-bold text-white line-clamp-1">
                  {listingContext.title}
                </p>
                <p className="text-[11px] text-emerald-400 font-mono font-bold">
                  {listingContext.price.toLocaleString()} {listingContext.currency}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Automatic Message Deletion Notice Banner */}
        <div className="bg-amber-500/10 border-b border-amber-500/20 px-3.5 py-2 flex items-center justify-center gap-2 shrink-0 text-center">
          <Clock className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <p className="text-[11px] text-amber-300 font-medium leading-tight">
            تنبيه: تُحذف جميع الرسائل تلقائياً بعد مرور أسبوع على إرسالها
          </p>
        </div>

        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950">
          {messages.map((msg) => {
            const isOwn = msg.senderId === currentUser.id;

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isOwn ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[82%] rounded-3xl p-3 text-xs leading-relaxed shadow-md ${
                    isOwn
                      ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-bl-sm'
                      : 'bg-slate-800/95 border border-slate-700/80 text-slate-100 rounded-br-sm'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.text}</p>

                  <div
                    className={`flex items-center gap-1 text-[9px] mt-1 opacity-70 ${
                      isOwn ? 'justify-end' : 'justify-start'
                    }`}
                  >
                    <span>
                      {new Date(msg.timestamp).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                    {isOwn && <CheckCheck className="w-3 h-3 text-white" />}
                  </div>
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Chat Message Input - Send button placed on the right */}
        <div className="p-3 bg-slate-800/90 border-t border-slate-700 shrink-0">
          <form onSubmit={handleSendText} className="flex items-center gap-2">
            {/* 1. زر إرسال الرسالة على اليمين */}
            <button
              type="submit"
              disabled={!inputText.trim()}
              className="px-3.5 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-40 text-white font-bold transition active:scale-95 cursor-pointer shrink-0 flex items-center justify-center gap-1.5 shadow-md shadow-emerald-950/40"
              title="إرسال الرسالة"
              aria-label="إرسال الرسالة"
            >
              <Send className="w-4 h-4 -scale-x-100 text-white" />
              <span className="text-xs font-bold">إرسال</span>
            </button>

            {/* 2. حقل إدخال الرسالة */}
            <input
              type="text"
              placeholder="اكتب رسالة لصاحب العرض..."
              value={inputText}
              onChange={(e) => {
                setInputText(e.target.value);
                triggerActivity();
              }}
              className="flex-1 bg-slate-950 border border-slate-700 rounded-2xl py-2.5 px-4 text-white text-xs placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </form>
        </div>
      </div>
    </div>
  );
};
