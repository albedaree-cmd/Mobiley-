import React, { useState } from 'react';
import { X, Code2, Copy, Check, FileCode, Smartphone, Database } from 'lucide-react';

interface KotlinCodeViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const KOTLIN_FILES = [
  {
    name: 'MainActivity.kt',
    tag: 'Jetpack Compose UI',
    code: `package com.mobiley.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mobiley.app.ui.theme.MobileyTheme
import com.mobiley.app.ui.screens.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MobileyTheme {
                MobileyAppNavigation()
            }
        }
    }
}

@Composable
fun MobileyAppNavigation() {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Splash) }
    var isOffline by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        when (val screen = currentScreen) {
            is Screen.Splash -> SplashScreen(
                onTimeout = { currentScreen = Screen.Home }
            )
            is Screen.Login -> LoginScreen(
                onLoginSuccess = { currentScreen = Screen.Home },
                onNavigateSignup = { currentScreen = Screen.Signup },
                onNavigateForgot = { currentScreen = Screen.ForgotPassword }
            )
            is Screen.Signup -> SignupScreen(
                onSendWhatsAppOtp = { phone ->
                    currentScreen = Screen.VerifyOtp(phone)
                }
            )
            is Screen.VerifyOtp -> OtpVerificationScreen(
                phone = screen.phone,
                onVerified = { currentScreen = Screen.Home }
            )
            is Screen.Home -> MainMarketScreen(
                onOpenChat = { sellerId, listingId ->
                    currentScreen = Screen.Chat(sellerId, listingId)
                }
            )
            is Screen.Chat -> ChatRoomScreen(
                sellerId = screen.sellerId,
                listingId = screen.listingId,
                onBack = { currentScreen = Screen.Home }
            )
            else -> {}
        }

        // Facebook-style Offline Dialog
        if (isOffline) {
            OfflineNetworkDialog(
                onRetry = { /* Check network connection */ }
            )
        }
    }
}`,
  },
  {
    name: 'SupabaseRepository.kt',
    tag: 'Database & Security',
    code: `package com.mobiley.app.data

import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Columns
import kotlinx.serialization.Serializable
import java.util.Date

@Serializable
data class PhoneListingDto(
    val id: String,
    val title: String,
    val model: String,
    val price: Long,
    val city: String,
    val location_details: String,
    val notes: String, // Max 50 chars validation
    val images: List<String>,
    val seller_id: String,
    val seller_name: String,
    val seller_phone: String,
    val seller_type: String, // "individual", "store", "kiosk"
    val likes: Int = 0,
    val dislikes: Int = 0,
    val created_at: Long = System.currentTimeMillis(),
    val expires_at: Long = System.currentTimeMillis() + (7 * 24 * 60 * 60 * 1000) // Auto-deleted after 1 week
)

class SupabaseRepository(private val client: SupabaseClient) {
    
    // Fetch active listings only (where expires_at > now)
    suspend fun getActiveListings(): List<PhoneListingDto> {
        val now = System.currentTimeMillis()
        return client.from("listings")
            .select {
                filter {
                    gt("expires_at", now)
                }
            }
            .decodeList<PhoneListingDto>()
    }

    // Insert phone ad with strict 50 chars notes sanitization
    suspend fun publishListing(listing: PhoneListingDto): Result<Unit> {
        return runCatching {
            require(listing.notes.length <= 50) { "الملاحظات يجب أن لا تتجاوز 50 حرفاً" }
            require(listing.images.size <= 6) { "الحد الأقصى المسموح 6 صور" }
            client.from("listings").insert(listing)
        }
    }

    // Like / Dislike mutation
    suspend fun reactToListing(listingId: String, reactionType: String): Result<Unit> {
        return runCatching {
            client.from("reactions").insert(mapOf(
                "listing_id" to listingId,
                "type" to reactionType
            ))
        }
    }
}`,
  },
  {
    name: 'AppSettingsManager.kt',
    tag: 'Settings & Account Deletion',
    code: `package com.mobiley.app.utils

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

class AppSettingsManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("mobiley_settings", Context.MODE_PRIVATE)

    fun setLanguage(languageCode: String) {
        prefs.edit().putString("language", languageCode).apply()
        val appLocale = LocaleListCompat.forLanguageTags(languageCode)
        AppCompatDelegate.setApplicationLocales(appLocale)
    }

    fun setDarkMode(enabled: Boolean) {
        prefs.edit().putBoolean("dark_mode", enabled).apply()
        AppCompatDelegate.setDefaultNightMode(
            if (enabled) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
    }

    suspend fun deleteAccount(userId: String): Result<Unit> {
        return runCatching {
            // Delete listings, chats, and account records
            prefs.edit().clear().apply()
        }
    }
}`,
  },
];

export const KotlinCodeViewerModal: React.FC<KotlinCodeViewerModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [selectedIdx, setSelectedIdx] = useState(0);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentFile = KOTLIN_FILES[selectedIdx];

  const handleCopy = () => {
    navigator.clipboard.writeText(currentFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-sm select-none">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-3xl overflow-hidden shadow-2xl flex flex-col h-[85vh]">
        {/* Header */}
        <div className="p-4 bg-slate-800/90 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-purple-500/20 border border-purple-500/40 text-purple-400 flex items-center justify-center">
              <Code2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <span>كود أندرويد Kotlin الأصلي (Android Source Code)</span>
                <span className="text-[10px] bg-purple-900/60 text-purple-300 px-2 py-0.5 rounded-full border border-purple-600/40 font-mono">
                  Kotlin + Jetpack Compose
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                هندسة الأكواد الأصلية لتطبيق mobiley المربوط مع Supabase
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-700 hover:bg-slate-600 text-slate-300 hover:text-white transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* File Tabs */}
        <div className="flex border-b border-slate-800 bg-slate-950/60 px-3 pt-2 gap-1 overflow-x-auto">
          {KOTLIN_FILES.map((file, idx) => (
            <button
              key={file.name}
              onClick={() => setSelectedIdx(idx)}
              className={`px-3 py-2 rounded-t-xl text-xs font-mono font-medium flex items-center gap-1.5 transition cursor-pointer shrink-0 ${
                selectedIdx === idx
                  ? 'bg-slate-900 text-purple-400 border-t-2 border-purple-500'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>{file.name}</span>
            </button>
          ))}
        </div>

        {/* Code Body */}
        <div className="flex-1 overflow-y-auto p-4 bg-slate-950 font-mono text-xs text-slate-300 relative">
          <button
            onClick={handleCopy}
            className="absolute top-3 left-3 z-10 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl text-xs font-sans flex items-center gap-1.5 border border-slate-700 transition cursor-pointer shadow-md"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'تم النسخ' : 'نسخ الكود'}</span>
          </button>

          <pre className="text-left font-mono leading-relaxed pt-8" dir="ltr">
            <code>{currentFile.code}</code>
          </pre>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-900 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-emerald-400" />
            <span>متوافق مع قاعدة بيانات Supabase وأندرويد SDK 34</span>
          </div>
          <span className="text-[10px] text-slate-500 font-mono">mobiley Android Build 1.0</span>
        </div>
      </div>
    </div>
  );
};
