import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, Bell, X, Sparkles, Tag, ChevronLeft } from 'lucide-react';
import { PushToastData } from '../types';

interface PushNotificationToastProps {
  toast: PushToastData | null;
  onDismiss: () => void;
  onAction?: (toast: PushToastData) => void;
}

export const PushNotificationToast: React.FC<PushNotificationToastProps> = ({
  toast,
  onDismiss,
  onAction,
}) => {
  // Auto dismiss after 6 seconds
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => {
      onDismiss();
    }, 6000);
    return () => clearTimeout(timer);
  }, [toast, onDismiss]);

  return (
    <AnimatePresence>
      {toast && (
        <motion.div
          key={toast.id}
          initial={{ opacity: 0, y: -40, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -20, scale: 0.95 }}
          transition={{ type: 'spring', stiffness: 400, damping: 30 }}
          className="fixed top-3 left-1/2 -translate-x-1/2 z-[100] w-[95%] max-w-md pointer-events-auto"
        >
          <div
            onClick={() => {
              if (onAction) {
                onAction(toast);
              } else if (toast.onClick) {
                toast.onClick();
              }
            }}
            className="bg-slate-900/95 backdrop-blur-md border border-emerald-500/40 rounded-2xl p-3.5 shadow-2xl shadow-emerald-950/40 flex items-center justify-between gap-3 cursor-pointer hover:bg-slate-850 hover:border-emerald-500 transition active:scale-[0.99] select-none"
          >
            {/* Left: Avatar or Type Icon */}
            <div className="relative shrink-0">
              {toast.avatar ? (
                <img
                  src={toast.avatar}
                  alt={toast.title}
                  className="w-11 h-11 rounded-full object-cover border-2 border-emerald-500 shadow-md"
                />
              ) : (
                <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-md">
                  {toast.type === 'message' ? (
                    <MessageCircle className="w-5 h-5" />
                  ) : toast.type === 'price' ? (
                    <Tag className="w-5 h-5" />
                  ) : (
                    <Bell className="w-5 h-5" />
                  )}
                </div>
              )}
            </div>

            {/* Middle: Content */}
            <div className="flex-1 min-w-0 text-right">
              <div className="flex items-center justify-between gap-2 mb-0.5">
                <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded font-mono">
                  {toast.type === 'message' ? 'رسالة جديدة' : 'إشعار جديد'}
                </span>
                <span className="text-[10px] text-slate-400">الآن</span>
              </div>
              <h4 className="text-xs font-bold text-white truncate">{toast.title}</h4>
              <p className="text-[11px] text-slate-300 truncate mt-0.5">{toast.body}</p>
            </div>

            {/* Right: Actions */}
            <div className="flex items-center gap-1.5 shrink-0" onClick={(e) => e.stopPropagation()}>
              <button
                onClick={() => {
                  if (onAction) {
                    onAction(toast);
                  } else if (toast.onClick) {
                    toast.onClick();
                  }
                }}
                className="px-2.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold transition flex items-center gap-0.5 shadow-sm"
              >
                <span>{toast.type === 'message' ? 'رد' : 'عرض'}</span>
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={onDismiss}
                className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
                title="إغلاق التنبيه"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
