import React, { useState } from 'react';
import { motion, AnimatePresence, PanInfo } from 'motion/react';
import {
  Bell,
  CheckCheck,
  X,
  Sparkles,
  MessageCircle,
  Tag,
  Clock,
  Trash2,
  ArrowLeftRight,
} from 'lucide-react';

interface NotificationItem {
  id: string;
  title: string;
  desc: string;
  time: string;
  isRead: boolean;
  type: 'system' | 'message' | 'price' | 'alert';
}

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenChats?: () => void;
}

const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'n1',
    title: 'مرحباً بك في Mobiley 🇸🇩',
    desc: 'تم تسجيل وتفعيل حسابك بنجاح في أكبر سوق هواتف بالسودان.',
    time: 'منذ نصف ساعة',
    isRead: false,
    type: 'system',
  },
  {
    id: 'n2',
    title: 'رسالة جديدة من مشتري',
    desc: 'استفسار جديد بخصوص هاتف iPhone 15 Pro Max المعروض في الخرطوم.',
    time: 'منذ ساعتين',
    isRead: false,
    type: 'message',
  },
  {
    id: 'n3',
    title: 'تحديث أسعار سوق الهواتف',
    desc: 'تم تحديث متوسط أسعار هواتف Samsung Galaxy S24 اليوم في سوق بحري.',
    time: 'منذ 5 ساعات',
    isRead: true,
    type: 'price',
  },
  {
    id: 'n4',
    title: 'تذكير: مدة صلاحية الإعلانات',
    desc: 'تذكر أن الإعلانات تظل معروضة لمدة 7 أيام ثم تحذف تلقائياً لضمان دقة الأسعار.',
    time: 'منذ يومين',
    isRead: true,
    type: 'alert',
  },
];

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
  onOpenChats,
}) => {
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);

  if (!isOpen) return null;

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  const markItemAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
    );
  };

  const removeNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const handleDragEnd = (id: string, info: PanInfo) => {
    const swipeDistance = Math.abs(info.offset.x);
    const swipeVelocity = Math.abs(info.velocity.x);

    // Dismiss if swiped more than 75px or flicked with speed
    if (swipeDistance > 75 || swipeVelocity > 350) {
      removeNotification(id);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm">
      <div className="w-full max-w-sm md:max-w-md bg-slate-900 border border-slate-700/80 rounded-3xl p-5 shadow-2xl relative my-auto max-h-[88vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">الإشعارات والتنبيهات</h3>
              <p className="text-[10px] text-slate-400">
                {unreadCount > 0 ? `${unreadCount} غير مقروء` : 'جميع الإشعارات مقروءة'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {unreadCount > 0 && (
              <button
                onClick={markAllAsRead}
                className="text-[11px] text-emerald-400 hover:text-emerald-300 flex items-center gap-1 bg-slate-800/80 hover:bg-slate-800 px-2 py-1 rounded-xl transition cursor-pointer"
                title="تحديد الكل كمقروء"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                <span>قراءة الكل</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Swipe Hint Banner */}
        {notifications.length > 0 && (
          <div className="pt-2 pb-1 text-[11px] text-slate-400 flex items-center justify-center gap-1.5 select-none shrink-0 bg-slate-950/40 rounded-xl my-1 px-2 border border-slate-800/60">
            <ArrowLeftRight className="w-3.5 h-3.5 text-emerald-400" />
            <span>اسحب أي إشعار لليمين أو اليسار لحذفه</span>
          </div>
        )}

        {/* Notifications List with Swipe-to-Remove gesture */}
        <div className="flex-1 overflow-y-auto py-2 space-y-2.5 pr-1 overflow-x-hidden">
          {notifications.length === 0 ? (
            <div className="py-12 text-center text-slate-400 flex flex-col items-center justify-center gap-2">
              <div className="w-12 h-12 rounded-full bg-slate-800/80 flex items-center justify-center text-slate-500">
                <Bell className="w-6 h-6" />
              </div>
              <p className="text-sm font-semibold text-slate-300">لا توجد إشعارات حالياً</p>
              <p className="text-xs text-slate-500">تم حذف أو قراءة جميع الإشعارات والتنبيهات</p>
            </div>
          ) : (
            <AnimatePresence mode="popLayout">
              {notifications.map((item) => {
                const isUnread = !item.isRead;
                return (
                  <div key={item.id} className="relative rounded-2xl overflow-hidden">
                    {/* Background Delete Indicator revealed when dragged */}
                    <div className="absolute inset-0 bg-red-950/80 border border-red-500/40 rounded-2xl flex items-center justify-between px-5 text-red-300">
                      <div className="flex items-center gap-1.5 text-xs font-bold">
                        <Trash2 className="w-4 h-4 text-red-400" />
                        <span>حذف</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-xs font-bold">
                        <span>حذف</span>
                        <Trash2 className="w-4 h-4 text-red-400" />
                      </div>
                    </div>

                    {/* Draggable Notification Item */}
                    <motion.div
                      layout
                      drag="x"
                      dragConstraints={{ left: 0, right: 0 }}
                      dragElastic={0.85}
                      onDragEnd={(_, info) => handleDragEnd(item.id, info)}
                      exit={{
                        opacity: 0,
                        x: 200,
                        transition: { duration: 0.25 },
                      }}
                      onClick={() => {
                        markItemAsRead(item.id);
                        if (item.type === 'message' && onOpenChats) {
                          onClose();
                          onOpenChats();
                        }
                      }}
                      className={`relative z-10 p-3 rounded-2xl transition-colors cursor-grab active:cursor-grabbing flex gap-3 select-none ${
                        isUnread
                          ? 'bg-slate-900 border border-emerald-500/40 shadow-sm'
                          : 'bg-slate-950/90 hover:bg-slate-900/90 border border-slate-800'
                      }`}
                    >
                      <div className="shrink-0 mt-0.5 pointer-events-none">
                        {item.type === 'system' && (
                          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                            <Sparkles className="w-4 h-4" />
                          </div>
                        )}
                        {item.type === 'message' && (
                          <div className="w-8 h-8 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center">
                            <MessageCircle className="w-4 h-4" />
                          </div>
                        )}
                        {item.type === 'price' && (
                          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                            <Tag className="w-4 h-4" />
                          </div>
                        )}
                        {item.type === 'alert' && (
                          <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center">
                            <Clock className="w-4 h-4" />
                          </div>
                        )}
                      </div>

                      <div className="flex-1 min-w-0 pointer-events-none">
                        <div className="flex items-center justify-between gap-1 mb-0.5">
                          <h4
                            className={`text-xs font-bold truncate ${
                              isUnread ? 'text-white' : 'text-slate-300'
                            }`}
                          >
                            {item.title}
                          </h4>
                          <span className="text-[10px] text-slate-500 shrink-0 font-mono">
                            {item.time}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-relaxed line-clamp-2">
                          {item.desc}
                        </p>
                      </div>

                      {/* Explicit trash icon button on hover / touch */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          removeNotification(item.id);
                        }}
                        className="opacity-40 hover:opacity-100 p-1 text-slate-400 hover:text-red-400 transition self-center shrink-0"
                        title="حذف الإشعار"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </motion.div>
                  </div>
                );
              })}
            </AnimatePresence>
          )}
        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-slate-800 shrink-0 text-center">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
