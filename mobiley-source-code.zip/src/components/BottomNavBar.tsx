import React from 'react';
import { Home, MessageCircle, Bell, User as UserIcon } from 'lucide-react';
import { User } from '../types';

export type BottomNavTab = 'home' | 'chat' | 'notifications' | 'profile';

interface BottomNavBarProps {
  activeTab: BottomNavTab;
  onSelectTab: (tab: BottomNavTab) => void;
  unreadChatCount?: number;
  unreadNotificationCount?: number;
  currentUser: User | null;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  activeTab,
  onSelectTab,
  unreadChatCount = 0,
  unreadNotificationCount = 0,
  currentUser,
}) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-900/95 backdrop-blur-md border-t border-slate-800/90 shadow-2xl">
      <div className="max-w-md mx-auto px-3 h-16 flex items-center justify-around">
        {/* 1. Home Tab */}
        <button
          onClick={() => onSelectTab('home')}
          className={`flex flex-col items-center justify-center gap-1 w-16 py-1 transition-all cursor-pointer ${
            activeTab === 'home'
              ? 'text-emerald-400 scale-105'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className="relative">
            <Home className="w-5 h-5" />
            {activeTab === 'home' && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-emerald-400 rounded-full" />
            )}
          </div>
          <span className="text-[10px] font-bold tracking-tight">الرئيسية</span>
        </button>

        {/* 2. Chat Tab */}
        <button
          onClick={() => onSelectTab('chat')}
          className={`flex flex-col items-center justify-center gap-1 w-16 py-1 transition-all cursor-pointer relative ${
            activeTab === 'chat'
              ? 'text-emerald-400 scale-105'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className="relative">
            <MessageCircle className="w-5 h-5" />
            {unreadChatCount > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-rose-500 text-white text-[9px] font-black font-mono w-4 h-4 rounded-full flex items-center justify-center shadow-md border border-slate-900 animate-pulse">
                {unreadChatCount}
              </span>
            )}
            {activeTab === 'chat' && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-emerald-400 rounded-full" />
            )}
          </div>
          <span className="text-[10px] font-bold tracking-tight">الدردشة</span>
        </button>

        {/* 3. Notifications Tab (notificiosn) */}
        <button
          onClick={() => onSelectTab('notifications')}
          className={`flex flex-col items-center justify-center gap-1 w-16 py-1 transition-all cursor-pointer relative ${
            activeTab === 'notifications'
              ? 'text-emerald-400 scale-105'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className="relative">
            <Bell className="w-5 h-5" />
            {unreadNotificationCount > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-amber-500 text-white text-[9px] font-black font-mono w-4 h-4 rounded-full flex items-center justify-center shadow-md border border-slate-900">
                {unreadNotificationCount}
              </span>
            )}
            {activeTab === 'notifications' && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-emerald-400 rounded-full" />
            )}
          </div>
          <span className="text-[10px] font-bold tracking-tight">الإشعارات</span>
        </button>

        {/* 4. Profile Tab */}
        <button
          onClick={() => onSelectTab('profile')}
          className={`flex flex-col items-center justify-center gap-1 w-16 py-1 transition-all cursor-pointer ${
            activeTab === 'profile'
              ? 'text-emerald-400 scale-105'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <div className="relative">
            {currentUser?.avatar ? (
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className={`w-5 h-5 rounded-full object-cover border ${
                  activeTab === 'profile' ? 'border-emerald-400' : 'border-slate-600'
                }`}
              />
            ) : (
              <UserIcon className="w-5 h-5" />
            )}
            {activeTab === 'profile' && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-emerald-400 rounded-full" />
            )}
          </div>
          <span className="text-[10px] font-bold tracking-tight">حسابي</span>
        </button>
      </div>
    </nav>
  );
};
