import React, { useState, useRef, useEffect } from 'react';
import {
  MessageCircle,
  Clock,
  MapPin,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Share2,
} from 'lucide-react';
import { PhoneListing, User } from '../types';
import { LazyImage } from './LazyImage';
import { FullscreenImageViewer } from './FullscreenImageViewer';

interface ListingCardProps {
  listing: PhoneListing;
  priority?: boolean;
  onLike?: (id: string) => void;
  onDislike?: (id: string) => void;
  onOpenChat: (sellerId: string, listing: PhoneListing) => void;
  onViewSellerProfile: (sellerId: string) => void;
  onShare?: (listing: PhoneListing) => void;
}

// Calculate human-friendly remaining time until 1 week expiration
function formatRemainingTime(expiresAt: number): string {
  const diffMs = expiresAt - Date.now();
  if (diffMs <= 0) return 'منتهي الصلاحية';

  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffDays = Math.floor(diffHours / 24);
  const remainingHours = diffHours % 24;

  if (diffDays > 0) {
    return `متبقي ${diffDays} يوم ${remainingHours > 0 ? `و ${remainingHours} س` : ''}`;
  }
  return `متبقي ${diffHours} ساعة`;
}

export const ListingCard: React.FC<ListingCardProps> = ({
  listing,
  priority = false,
  onOpenChat,
  onViewSellerProfile,
  onShare,
}) => {
  const [activeImageIdx, setActiveImageIdx] = useState(0);
  const [copied, setCopied] = useState(false);
  const [isUserActive, setIsUserActive] = useState(false);
  const [fullscreenModal, setFullscreenModal] = useState<{
    isOpen: boolean;
    images: string[];
    initialIndex: number;
    title: string;
  }>({
    isOpen: false,
    images: [],
    initialIndex: 0,
    title: '',
  });
  const activityTimerRef = useRef<NodeJS.Timeout | null>(null);

  const triggerActivity = () => {
    setIsUserActive(true);
    if (activityTimerRef.current) clearTimeout(activityTimerRef.current);
    activityTimerRef.current = setTimeout(() => {
      setIsUserActive(false);
    }, 4000);
  };

  useEffect(() => {
    return () => {
      if (activityTimerRef.current) clearTimeout(activityTimerRef.current);
    };
  }, []);

  const images = listing.images && listing.images.length > 0
    ? listing.images
    : ['https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=800&auto=format&fit=crop&q=80'];

  const remaining = formatRemainingTime(listing.expiresAt);

  return (
    <article className="bg-slate-900 border border-slate-800/90 rounded-3xl overflow-hidden shadow-lg hover:border-slate-700 transition duration-200">
      {/* 1. اسم الناشر ومؤشر متصل */}
      <div className="p-3.5 flex items-center justify-between border-b border-slate-800/60 bg-slate-900/70">
        <div className="flex items-center gap-2.5 group">
          {/* صورة شخصية تفتح بشاشة كاملة عند الضغط عليها */}
          <div
            onClick={(e) => {
              e.stopPropagation();
              setFullscreenModal({
                isOpen: true,
                images: [listing.sellerAvatar],
                initialIndex: 0,
                title: listing.sellerName,
              });
            }}
            className="relative cursor-pointer"
            title="اضغط لعرض الصورة الشخصية بشاشة كاملة"
          >
            <LazyImage
              src={listing.sellerAvatar}
              alt={listing.sellerName}
              containerClassName="w-10 h-10 rounded-full border-2 border-emerald-500/40 hover:border-emerald-400 hover:scale-105 transition"
              className="w-full h-full object-cover"
              priority={priority}
            />
            <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 rounded-full border-2 border-slate-900 z-10" />
          </div>

          <div className="flex items-center gap-2">
            <h3
              onClick={() => onViewSellerProfile(listing.sellerId)}
              className="font-bold text-sm text-white hover:text-emerald-400 transition cursor-pointer"
              title="عرض الملف الشخصي"
            >
              {listing.sellerName}
            </h3>

            {/* مؤشر حالة 'متصل' (نقطة خضراء) بجانب اسم المستخدم */}
            <div
              onClick={(e) => {
                e.stopPropagation();
                triggerActivity();
              }}
              onMouseEnter={() => setIsUserActive(true)}
              onMouseLeave={() => setIsUserActive(false)}
              className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/25 text-emerald-400 text-[10px] font-medium transition-all duration-300 select-none cursor-pointer"
              title={isUserActive ? 'المستخدم متصل الآن' : 'متصل'}
            >
              <span className="relative flex h-2 w-2 shrink-0">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
              </span>
              {/* يظهر النص 'متصل' فقط عند نشاط المستخدم */}
              <span
                className={`transition-all duration-300 overflow-hidden whitespace-nowrap ${
                  isUserActive
                    ? 'max-w-[48px] opacity-100'
                    : 'max-w-0 opacity-0 group-hover:max-w-[48px] group-hover:opacity-100'
                }`}
              >
                متصل
              </span>
            </div>
          </div>
        </div>

        {/* مؤقت الحذف التلقائي بعد أسبوع */}
        <div
          title="يحذف العرض تلقائياً بعد أسبوع"
          className="flex items-center gap-1 bg-amber-500/10 border border-amber-500/25 px-2 py-1 rounded-xl text-[10px] text-amber-300 font-medium shrink-0"
        >
          <Clock className="w-3 h-3 text-amber-400 shrink-0" />
          <span>{remaining}</span>
        </div>
      </div>

      {/* 2. ومن ثم صور المنتج مع خاصية Lazy Loading والفتح بشاشة كاملة والسحب يمين وشمال */}
      <div
        onClick={() => {
          setFullscreenModal({
            isOpen: true,
            images,
            initialIndex: activeImageIdx,
            title: `${listing.title} - ${listing.model}`,
          });
        }}
        className="relative aspect-[4/3] w-full bg-slate-950 overflow-hidden select-none group cursor-pointer"
        title="اضغط لعرض الصور بشاشة كاملة (مع إمكانية السحب يميناً ويساراً)"
      >
        <LazyImage
          src={images[activeImageIdx]}
          alt={listing.title}
          fallbackIcon="phone"
          containerClassName="w-full h-full"
          className="w-full h-full object-cover transition duration-300 group-hover:scale-105"
          priority={priority && activeImageIdx === 0}
        />

        {/* Fullscreen Hint Badge on Hover */}
        <div className="absolute top-3 right-3 px-2 py-1 rounded-lg bg-black/60 backdrop-blur-sm text-[10px] text-white flex items-center gap-1 opacity-0 group-hover:opacity-100 transition z-20">
          <span>تكبير</span>
        </div>

        {/* Multi-image indicators and navigation */}
        {images.length > 1 && (
          <>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setActiveImageIdx((prev) => (prev > 0 ? prev - 1 : images.length - 1));
              }}
              className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/60 hover:bg-black/80 text-white flex items-center justify-center backdrop-blur-sm transition cursor-pointer z-10"
              title="السابقة"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setActiveImageIdx((prev) => (prev < images.length - 1 ? prev + 1 : 0));
              }}
              className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/60 hover:bg-black/80 text-white flex items-center justify-center backdrop-blur-sm transition cursor-pointer z-10"
              title="التالية"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            {/* Thumbnail dots */}
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 bg-black/60 px-2.5 py-1 rounded-full backdrop-blur-sm z-10">
              {images.map((_, idx) => (
                <span
                  key={idx}
                  className={`w-1.5 h-1.5 rounded-full transition-all ${
                    activeImageIdx === idx ? 'w-4 bg-emerald-400' : 'bg-white/40'
                  }`}
                />
              ))}
            </div>

            {/* Photo count indicator */}
            <div className="absolute top-3 left-3 bg-black/70 text-[10px] text-white font-mono px-2 py-0.5 rounded-lg backdrop-blur-sm z-10">
              {activeImageIdx + 1} / {images.length}
            </div>
          </>
        )}
      </div>

      {/* 3. وتحتها: الموقع واسم المنتج وموديله والسعر والملاحظات وكلمة دردشة */}
      <div className="p-4 space-y-3">
        {/* الموقع */}
        <div className="flex items-center gap-1.5 text-xs text-slate-300">
          <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span className="font-semibold text-white">{listing.city}</span>
          {listing.locationDetails && (
            <>
              <span className="text-slate-500">•</span>
              <span className="text-slate-400">{listing.locationDetails}</span>
            </>
          )}
        </div>

        {/* اسم المنتج وموديله والسعر */}
        <div className="flex items-start justify-between gap-3 pt-1 border-t border-slate-800/60">
          <div className="space-y-1 min-w-0">
            {/* اسم المنتج */}
            <h4 className="font-bold text-base text-white leading-snug">
              {listing.title}
            </h4>
            {/* موديل المنتج */}
            <div className="text-xs text-emerald-400 font-medium flex items-center gap-1">
              <Sparkles className="w-3 h-3 shrink-0" />
              <span>الموديل: {listing.model}</span>
            </div>
          </div>

          {/* السعر */}
          <div className="text-left shrink-0 bg-slate-950/80 px-3 py-1.5 rounded-xl border border-slate-800">
            <span className="text-base font-black text-emerald-400 font-mono">
              {listing.price.toLocaleString()}
            </span>{' '}
            <span className="text-[11px] text-slate-400 font-semibold">{listing.currency}</span>
          </div>
        </div>

        {/* الملاحظات */}
        {listing.notes && (
          <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-2.5 text-xs text-slate-300 leading-relaxed">
            <span className="text-slate-500 font-medium ml-1">ملاحظات:</span>
            <span>{listing.notes}</span>
          </div>
        )}

        {/* أزرار المشاركة والدردشة */}
        <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2.5">
          {/* زر مشاركة */}
          <button
            onClick={async () => {
              if (onShare) {
                onShare(listing);
                return;
              }
              const shareText = `شاهد عرض هاتف ${listing.title} (${listing.model}) بسعر ${listing.price.toLocaleString()} ${listing.currency} على تطبيق Mobiley في ${listing.city}`;
              const shareUrl = window.location.href;

              if (navigator.share) {
                try {
                  await navigator.share({
                    title: `Mobiley - ${listing.title}`,
                    text: shareText,
                    url: shareUrl,
                  });
                  return;
                } catch {
                  // Fallback to clipboard
                }
              }

              try {
                await navigator.clipboard.writeText(`${shareText}\n${shareUrl}`);
                setCopied(true);
                setTimeout(() => setCopied(false), 2000);
              } catch {
                // Fallback
              }
            }}
            className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-2xl text-xs font-bold transition cursor-pointer border active:scale-95 ${
              copied
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : 'bg-slate-800/90 text-slate-300 hover:text-white hover:bg-slate-800 border-slate-700/60'
            }`}
            title="مشاركة العرض"
          >
            <Share2 className="w-4 h-4 text-emerald-400" />
            <span>{copied ? 'تم النسخ' : 'مشاركة'}</span>
          </button>

          {/* كلمة دردشة فقط */}
          <button
            onClick={() => onOpenChat(listing.sellerId, listing)}
            className="flex-1 py-2.5 px-4 bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-bold text-sm rounded-2xl transition shadow-md shadow-emerald-950/40 flex items-center justify-center gap-2 active:scale-95 cursor-pointer"
          >
            <MessageCircle className="w-4 h-4" />
            <span>دردشة</span>
          </button>
        </div>
      </div>

      {/* Fullscreen Image Lightbox Viewer with Left/Right Swipe Navigation */}
      <FullscreenImageViewer
        isOpen={fullscreenModal.isOpen}
        images={fullscreenModal.images}
        initialIndex={fullscreenModal.initialIndex}
        title={fullscreenModal.title}
        onClose={() =>
          setFullscreenModal({
            isOpen: false,
            images: [],
            initialIndex: 0,
            title: '',
          })
        }
      />
    </article>
  );
};
