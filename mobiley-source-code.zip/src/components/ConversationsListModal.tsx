import React, { useState, useEffect } from 'react';
import {
  X,
  Search,
  MessageCircle,
  CheckCheck,
  Trash2,
  ChevronLeft,
  Users,
  Sparkles,
} from 'lucide-react';
import { User, Conversation, PhoneListing } from '../types';
import { DatabaseService } from '../services/supabaseService';
import { INITIAL_USERS } from '../data/sudanData';
import { LazyImage } from './LazyImage';

interface ConversationsListModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onSelectConversation: (partner: User, listingContext?: PhoneListing | null) => void;
  allListings?: PhoneListing[];
}

export const ConversationsListModal: React.FC<ConversationsListModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onSelectConversation,
  allListings = [],
}) => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'unread'>('all');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const loadConversations = () => {
    if (!currentUser) return;
    const convs = DatabaseService.getConversations(currentUser.id);
    setConversations(convs);
  };

  useEffect(() => {
    if (isOpen) {
      loadConversations();
    }
  }, [isOpen, currentUser?.id]);

  if (!isOpen) return null;

  const totalUnread = conversations.reduce((acc, c) => acc + (c.unreadCount || 0), 0);

  // Filtered conversations
  const filteredConversations = conversations.filter((c) => {
    // Filter tab
    if (activeFilter === 'unread' && c.unreadCount === 0) return false;

    // Search query
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    const partnerName = c.partner.name.toLowerCase();
    const msgText = (c.lastMessage?.text || '').toLowerCase();
    const partnerPhone = (c.partner.phone || '').toLowerCase();

    return (
      partnerName.includes(q) ||
      msgText.includes(q) ||
      partnerPhone.includes(q)
    );
  });

  const handleDeleteConversation = (partnerId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    DatabaseService.deleteConversation(partnerId, currentUser.id);
    setConversations((prev) => prev.filter((c) => c.partner.id !== partnerId));
    setConfirmDeleteId(null);
  };

  // Format relative timestamp
  const formatTime = (timestamp: number) => {
    const diffMs = Date.now() - timestamp;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffMins < 1) return 'الآن';
    if (diffMins < 60) return `منذ ${diffMins} د`;
    if (diffHours < 24) {
      return new Date(timestamp).toLocaleTimeString('ar-SD', {
        hour: '2-digit',
        minute: '2-digit',
      });
    }
    if (diffDays === 1) return 'أمس';
    if (diffDays < 7) return `منذ ${diffDays} أيام`;
    return new Date(timestamp).toLocaleDateString('ar-SD', {
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-2 sm:p-4 select-none">
      <div className="w-full max-w-md h-[92vh] bg-slate-900 border border-slate-700/80 rounded-3xl flex flex-col overflow-hidden shadow-2xl relative">
        {/* Header */}
        <header className="p-4 bg-slate-800/90 border-b border-slate-700/80 shrink-0">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-md shadow-emerald-950/40">
                <MessageCircle className="w-4 h-4" />
              </div>
              {totalUnread > 0 && (
                <span className="bg-emerald-500 text-white text-[11px] font-bold px-2 py-0.5 rounded-full font-mono">
                  {totalUnread} غير مقروءة
                </span>
              )}
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-700/60 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
              title="إغلاق"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Search bar */}
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
            <input
              type="text"
              placeholder="ابحث بالاسم أو نص الرسالة..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700/80 rounded-2xl py-2 pl-9 pr-9 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-2 mt-3">
            <button
              onClick={() => setActiveFilter('all')}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
                activeFilter === 'all'
                  ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-900/40'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              الكل ({conversations.length})
            </button>

            <button
              onClick={() => setActiveFilter('unread')}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 flex items-center gap-1.5 ${
                activeFilter === 'unread'
                  ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-900/40'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <span>غير مقروءة</span>
              {totalUnread > 0 && (
                <span className="w-4 h-4 rounded-full bg-rose-500 text-[9px] flex items-center justify-center font-mono">
                  {totalUnread}
                </span>
              )}
            </button>
          </div>
        </header>

        {/* Conversations Stream */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-800/80 bg-slate-950/60 p-2">
          {filteredConversations.length > 0 ? (
            filteredConversations.map((conv) => {
              const partner = conv.partner;
              const lastMsg = conv.lastMessage;
              const isOwnLastMsg = lastMsg?.senderId === currentUser.id;

              // Find associated listing if present
              const matchedListing = conv.listingId
                ? allListings.find((l) => l.id === conv.listingId)
                : null;

              return (
                <div
                  key={conv.id}
                  onClick={() => onSelectConversation(partner as User, matchedListing)}
                  className="p-3 rounded-2xl hover:bg-slate-800/70 transition-all cursor-pointer flex items-center justify-between gap-3 group active:scale-[0.99]"
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    {/* Partner Avatar with Online Green Dot */}
                    <div className="relative shrink-0">
                      <LazyImage
                        src={partner.avatar}
                        alt={partner.name}
                        containerClassName="w-12 h-12 rounded-full border-2 border-slate-700 group-hover:border-emerald-500 transition overflow-hidden"
                        className="w-full h-full object-cover"
                        priority={true}
                      />
                      <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-slate-900 z-10" />
                    </div>

                    {/* Content info: Only person's name and message preview */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1.5">
                        <h4 className="text-xs font-black text-white truncate">
                          {partner.name}
                        </h4>

                        <span className="text-[10px] text-slate-400 font-mono shrink-0">
                          {formatTime(lastMsg.timestamp)}
                        </span>
                      </div>

                      {/* Last Message Preview */}
                      <div className="flex items-center gap-1.5">
                        {isOwnLastMsg && (
                          <CheckCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        )}
                        <p
                          className={`text-xs truncate ${
                            conv.unreadCount > 0
                              ? 'text-white font-bold'
                              : 'text-slate-400'
                          }`}
                        >
                          {isOwnLastMsg ? 'أنت: ' : ''}
                          {lastMsg.text || 'رسالة جديدة'}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Badges & Actions */}
                  <div className="flex flex-col items-end gap-2 shrink-0">
                    {conv.unreadCount > 0 ? (
                      <span className="bg-emerald-500 text-white text-[10px] font-black font-mono w-5 h-5 rounded-full flex items-center justify-center shadow-md">
                        {conv.unreadCount}
                      </span>
                    ) : (
                      <ChevronLeft className="w-4 h-4 text-slate-600 group-hover:text-emerald-400 transition" />
                    )}

                    {/* Delete conversation */}
                    {confirmDeleteId === partner.id ? (
                      <div className="flex items-center gap-1 mt-1" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={(e) => handleDeleteConversation(partner.id, e)}
                          className="px-2 py-0.5 rounded bg-rose-600 text-white text-[10px] font-bold hover:bg-rose-500"
                        >
                          حذف
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setConfirmDeleteId(null);
                          }}
                          className="px-1.5 py-0.5 rounded bg-slate-700 text-slate-300 text-[10px]"
                        >
                          إلغاء
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setConfirmDeleteId(partner.id);
                        }}
                        className="opacity-0 group-hover:opacity-100 p-1 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition"
                        title="حذف المحادثة"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          ) : (
            <div className="py-12 px-4 text-center flex flex-col items-center justify-center">
              <div className="w-14 h-14 rounded-2xl bg-slate-800/80 border border-slate-700 flex items-center justify-center text-slate-400 mb-3">
                <Users className="w-7 h-7" />
              </div>
              <h3 className="text-sm font-bold text-white mb-1">
                {searchQuery ? 'لم يتم العثور على محادثات مطابقة' : 'لا توجد محادثات سابقة'}
              </h3>
              <p className="text-xs text-slate-400 max-w-xs mb-4">
                {searchQuery
                  ? 'جرّب البحث باسم آخر أو إلغاء فلتر البحث.'
                  : 'يمكنك بدء محادثة فورية مع أي شخص مباشرة من إعلانات الهواتف.'}
              </p>

              {/* Quick Contacts to start chatting */}
              <div className="w-full mt-2 pt-3 border-t border-slate-800/80">
                <p className="text-[11px] font-bold text-emerald-400 mb-3 flex items-center justify-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>مستخدمون متاحون للدردشة الآن:</span>
                </p>

                <div className="space-y-2">
                  {INITIAL_USERS.slice(0, 3).map((seller) => (
                    <button
                      key={seller.id}
                      onClick={() => onSelectConversation(seller, allListings[0] || null)}
                      className="w-full p-2.5 rounded-xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 flex items-center justify-between transition cursor-pointer group"
                    >
                      <div className="flex items-center gap-2.5">
                        <LazyImage
                          src={seller.avatar}
                          alt={seller.name}
                          containerClassName="w-8 h-8 rounded-full border border-emerald-500/50 overflow-hidden shrink-0"
                          className="w-full h-full object-cover"
                        />
                        <div className="text-right">
                          <p className="text-xs font-bold text-white group-hover:text-emerald-300">
                            {seller.name}
                          </p>
                        </div>
                      </div>

                      <span className="text-[11px] font-bold text-emerald-400 flex items-center gap-1 bg-emerald-500/10 px-2 py-1 rounded-lg">
                        <MessageCircle className="w-3 h-3" />
                        <span>بدء محادثة</span>
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer info */}
        <footer className="p-3 bg-slate-800/90 border-t border-slate-700/80 flex items-center justify-between text-xs text-slate-400 shrink-0">
          <div className="flex items-center gap-1.5 text-[11px]">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>تُحذف الرسائل تلقائياً بعد أسبوع من إرسالها</span>
          </div>

          <span className="text-[11px] font-bold text-slate-300">
            {conversations.length} {conversations.length === 1 ? 'شخص' : 'أشخاص'}
          </span>
        </footer>
      </div>
    </div>
  );
};
