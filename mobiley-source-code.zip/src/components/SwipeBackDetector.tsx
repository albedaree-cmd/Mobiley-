import React, { useState, useRef, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface SwipeBackDetectorProps {
  children: React.ReactNode;
  canGoBack: boolean;
  onBack: () => void;
}

export const SwipeBackDetector: React.FC<SwipeBackDetectorProps> = ({
  children,
  canGoBack,
  onBack,
}) => {
  const [swipeDirection, setSwipeDirection] = useState<'left' | 'right' | null>(null);
  const [swipeProgress, setSwipeProgress] = useState(0);

  const touchStartX = useRef(0);
  const touchStartY = useRef(0);
  const isDragging = useRef(false);

  const handleTouchStart = (e: React.TouchEvent) => {
    if (!canGoBack || e.touches.length !== 1) return;
    touchStartX.current = e.touches[0].clientX;
    touchStartY.current = e.touches[0].clientY;
    isDragging.current = true;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging.current || !canGoBack || e.touches.length !== 1) return;
    const currentX = e.touches[0].clientX;
    const currentY = e.touches[0].clientY;
    const deltaX = currentX - touchStartX.current;
    const deltaY = currentY - touchStartY.current;

    // Check if movement is mostly horizontal
    if (Math.abs(deltaX) > 20 && Math.abs(deltaX) > Math.abs(deltaY) * 1.4) {
      const dir = deltaX > 0 ? 'right' : 'left';
      setSwipeDirection(dir);
      const progress = Math.min(1, Math.abs(deltaX) / 80);
      setSwipeProgress(progress);
    } else if (Math.abs(deltaY) > 30) {
      // User is scrolling vertically, cancel swipe gesture
      isDragging.current = false;
      setSwipeDirection(null);
      setSwipeProgress(0);
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!isDragging.current) return;
    isDragging.current = false;

    const currentX = e.changedTouches[0].clientX;
    const currentY = e.changedTouches[0].clientY;
    const deltaX = currentX - touchStartX.current;
    const deltaY = currentY - touchStartY.current;

    // Threshold for triggering back: at least 60px horizontal distance
    if (canGoBack && Math.abs(deltaX) > 60 && Math.abs(deltaX) > Math.abs(deltaY) * 1.3) {
      onBack();
    }

    setSwipeDirection(null);
    setSwipeProgress(0);
  };

  // Mouse drag support for desktop browser testing
  const mouseDownX = useRef(0);
  const mouseDownY = useRef(0);
  const isMouseDragging = useRef(false);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!canGoBack || e.button !== 0) return;
    // Only start if clicking near edges or if target isn't an input/button
    const target = e.target as HTMLElement;
    if (target.closest('input, textarea, button, select, a')) return;

    mouseDownX.current = e.clientX;
    mouseDownY.current = e.clientY;
    isMouseDragging.current = true;
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isMouseDragging.current || !canGoBack) return;
    const deltaX = e.clientX - mouseDownX.current;
    const deltaY = e.clientY - mouseDownY.current;

    if (Math.abs(deltaX) > 25 && Math.abs(deltaX) > Math.abs(deltaY) * 1.4) {
      setSwipeDirection(deltaX > 0 ? 'right' : 'left');
      setSwipeProgress(Math.min(1, Math.abs(deltaX) / 80));
    }
  };

  const handleMouseUp = (e: React.MouseEvent) => {
    if (!isMouseDragging.current) return;
    isMouseDragging.current = false;

    const deltaX = e.clientX - mouseDownX.current;
    const deltaY = e.clientY - mouseDownY.current;

    if (canGoBack && Math.abs(deltaX) > 70 && Math.abs(deltaX) > Math.abs(deltaY) * 1.3) {
      onBack();
    }

    setSwipeDirection(null);
    setSwipeProgress(0);
  };

  return (
    <div
      className="relative w-full min-h-screen flex flex-col"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
    >
      {/* Android-style Back Gesture Visual Indicator on Right Edge */}
      {swipeDirection === 'left' && swipeProgress > 0.2 && (
        <div
          className="fixed right-3 top-1/2 -translate-y-1/2 z-[999] pointer-events-none transition-all duration-75"
          style={{ transform: `translateY(-50%) scale(${0.7 + swipeProgress * 0.4})` }}
        >
          <div className="w-11 h-11 rounded-full bg-emerald-600/90 text-white shadow-xl shadow-emerald-950/60 flex items-center justify-center border border-emerald-400/50 backdrop-blur-sm animate-pulse">
            <ChevronRight className="w-6 h-6" />
          </div>
        </div>
      )}

      {/* Android-style Back Gesture Visual Indicator on Left Edge */}
      {swipeDirection === 'right' && swipeProgress > 0.2 && (
        <div
          className="fixed left-3 top-1/2 -translate-y-1/2 z-[999] pointer-events-none transition-all duration-75"
          style={{ transform: `translateY(-50%) scale(${0.7 + swipeProgress * 0.4})` }}
        >
          <div className="w-11 h-11 rounded-full bg-emerald-600/90 text-white shadow-xl shadow-emerald-950/60 flex items-center justify-center border border-emerald-400/50 backdrop-blur-sm animate-pulse">
            <ChevronLeft className="w-6 h-6" />
          </div>
        </div>
      )}

      {children}
    </div>
  );
};
