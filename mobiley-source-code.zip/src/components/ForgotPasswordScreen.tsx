import React, { useState } from 'react';
import { Phone, Lock, Eye, EyeOff, KeyRound, ArrowRight, CheckCircle2, AlertCircle } from 'lucide-react';
import { ModernAnimatedPhone } from './ModernAnimatedPhone';
import { sanitizeInput } from '../services/supabaseService';

interface ForgotPasswordScreenProps {
  onBackToLogin: () => void;
  onResetSuccess: () => void;
}

export const ForgotPasswordScreen: React.FC<ForgotPasswordScreenProps> = ({
  onBackToLogin,
  onResetSuccess,
}) => {
  const [step, setStep] = useState<'request' | 'verify'>('request');
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const handleRequestCode = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPhone = sanitizeInput(phone).replace(/\s+/g, '');
    if (!cleanPhone || cleanPhone.length < 9) {
      setErrorMsg('يرجى إدخال رقم هاتف سوداني صحيح');
      return;
    }
    setErrorMsg('');
    setStep('verify');
    setSuccessMsg('تم إرسال كود إعادة التعيين التجريبي (9988) إلى واتساب');
  };

  const handleReset = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code || code !== '9988') {
      setErrorMsg('كود التحقق غير صحيح، أدخل الكود التجريبي: 9988');
      return;
    }
    if (!newPassword || newPassword.length < 6) {
      setErrorMsg('كلمة السر يجب أن تكون 6 خانات على الأقل');
      return;
    }
    if (newPassword !== confirmPassword) {
      setErrorMsg('كلمتا السر غير متطابقتين');
      return;
    }

    setErrorMsg('');
    setSuccessMsg('تم تغيير كلمة السر بنجاح! يتم نقلك لتسجيل الدخول...');
    setTimeout(() => {
      onResetSuccess();
    }, 1200);
  };

  return (
    <div className="min-h-screen w-full bg-slate-950 flex flex-col justify-between p-4 max-w-md mx-auto relative overflow-y-auto">
      {/* Top Header */}
      <div className="flex items-center justify-between pt-2 pb-1">
        <button
          onClick={onBackToLogin}
          className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white transition flex items-center gap-1.5 text-xs cursor-pointer"
        >
          <ArrowRight className="w-4 h-4" />
          <span>الرجوع للدخول</span>
        </button>
        <span className="text-xs font-mono text-emerald-400">استعادة الحساب</span>
      </div>

      <div className="flex flex-col items-center text-center my-4">
        <ModernAnimatedPhone size="md" showWaves={false} isFloating={true} className="mb-3" />
        <h2 className="text-2xl font-black text-white">إعادة تعيين كلمة السر</h2>
        <p className="text-xs text-slate-400 mt-1 max-w-xs">
          أدخل رقم هاتفك لاستلام رمز التحقق وإعادة تعيين كلمة مرور جديدة
        </p>
      </div>

      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl backdrop-blur-md mb-4">
        {errorMsg && (
          <div className="mb-4 p-3 bg-rose-500/15 border border-rose-500/30 rounded-xl flex items-center gap-2 text-rose-300 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="mb-4 p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-xl flex items-center gap-2 text-emerald-300 text-xs">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{successMsg}</span>
          </div>
        )}

        {step === 'request' ? (
          <form onSubmit={handleRequestCode} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                رقم الهاتف المسجل
              </label>
              <div className="relative flex items-center">
                <div className="absolute right-3 text-slate-400 pointer-events-none">
                  <Phone className="w-4 h-4 text-emerald-400" />
                </div>
                <input
                  type="tel"
                  dir="ltr"
                  placeholder="9XXXXXXXX"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-slate-950/90 border border-slate-700/80 rounded-2xl py-3 pr-10 pl-24 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 text-sm font-mono transition"
                />
                <div className="absolute left-2.5 flex items-center gap-1 bg-slate-800 border border-slate-700 px-2 py-1 rounded-xl text-xs font-mono text-emerald-400">
                  <span>🇸🇩</span>
                  <span>+249</span>
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-2xl transition shadow-lg shadow-emerald-950/40 flex items-center justify-center gap-2 cursor-pointer"
            >
              <KeyRound className="w-4 h-4" />
              <span className="text-sm">إرسال كود الاستعادة عبر واتساب</span>
            </button>
          </form>
        ) : (
          <form onSubmit={handleReset} className="space-y-3.5">
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-semibold text-slate-300">
                  كود التحقق المستلم
                </label>
                <button
                  type="button"
                  onClick={() => setCode('9988')}
                  className="text-[11px] text-emerald-400 underline cursor-pointer"
                >
                  استخدام الكود التجريبي (9988)
                </button>
              </div>
              <input
                type="text"
                dir="ltr"
                placeholder="9988"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-2xl py-2.5 px-3 text-white text-center font-mono text-base font-bold tracking-widest focus:border-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                كلمة السر الجديدة
              </label>
              <div className="relative flex items-center">
                <div className="absolute right-3 text-slate-400 pointer-events-none">
                  <Lock className="w-4 h-4 text-emerald-400" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-2xl py-2.5 pr-10 pl-8 text-white text-sm focus:border-emerald-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                تأكيد كلمة السر الجديدة
              </label>
              <div className="relative flex items-center">
                <div className="absolute right-3 text-slate-400 pointer-events-none">
                  <Lock className="w-4 h-4 text-emerald-400" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-2xl py-2.5 pr-10 pl-8 text-white text-sm focus:border-emerald-500 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-2.5 text-slate-400 hover:text-white transition cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-2xl transition shadow-lg shadow-emerald-950/40 flex items-center justify-center gap-2 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span className="text-sm">حفظ كلمة السر والدخول</span>
            </button>
          </form>
        )}
      </div>

      <div className="py-2 text-center">
        <button
          onClick={onBackToLogin}
          className="text-xs text-slate-400 hover:text-emerald-400 transition cursor-pointer"
        >
          تذكرت كلمة السر؟ <span className="text-emerald-400 font-bold underline">تسجيل الدخول</span>
        </button>
      </div>
    </div>
  );
};
