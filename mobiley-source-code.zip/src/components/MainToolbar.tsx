import React, { useState } from 'react';
import {
  Search,
  X,
  MoreVertical,
  Shield,
  Info,
  PhoneCall,
  Code2,
  Download,
  LogOut,
} from 'lucide-react';
import { User as UserType } from '../types';

interface MainToolbarProps {
  currentUser: UserType | null;
  unreadCount: number;
  searchQuery?: string;
  onSearchChange?: (query: string) => void;
  onOpenChats: () => void;
  onOpenProfile: (user: UserType) => void;
  onOpenPrivacyPolicy: () => void;
  onOpenAbout: () => void;
  onOpenContact: () => void;
  onOpenKotlinCode: () => void;
  onLogout: () => void;
}

export const MainToolbar: React.FC<MainToolbarProps> = ({
  currentUser,
  unreadCount,
  searchQuery = '',
  onSearchChange,
  onOpenChats,
  onOpenProfile,
  onOpenPrivacyPolicy,
  onOpenAbout,
  onOpenContact,
  onOpenKotlinCode,
  onLogout,
}) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [isSearchActive, setIsSearchActive] = useState(Boolean(searchQuery));

  return (
    <header className="sticky top-0 z-30 w-full bg-slate-900/95 backdrop-blur-md border-b border-slate-800/90 shadow-sm">
      <div className="max-w-md mx-auto px-3.5 h-12 flex items-center justify-between gap-2.5">
        {/* Right Side: 3-dots Menu Button + Search Icon next to it */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* 3-dots Menu Button */}
          <div className="relative">
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              title="خيارات إضافية"
              className="p-1.5 rounded-full bg-slate-800/90 hover:bg-slate-700 text-slate-200 hover:text-white transition active:scale-95 border border-slate-700/50 cursor-pointer"
            >
              <MoreVertical className="w-4.5 h-4.5" />
            </button>

            {/* Dropdown Menu - aligned to the right side */}
            {menuOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setMenuOpen(false)}
                />
                <div className="absolute right-0 mt-1.5 w-52 bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl z-50 py-2 text-xs divide-y divide-slate-800 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
                  <div className="py-1">
                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        onOpenPrivacyPolicy();
                      }}
                      className="w-full px-4 py-2 flex items-center gap-2.5 text-slate-300 hover:text-white hover:bg-slate-800 transition text-right cursor-pointer"
                    >
                      <Shield className="w-4 h-4 text-emerald-400" />
                      <span>سياسة الخصوصية</span>
                    </button>

                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        onOpenAbout();
                      }}
                      className="w-full px-4 py-2 flex items-center gap-2.5 text-slate-300 hover:text-white hover:bg-slate-800 transition text-right cursor-pointer"
                    >
                      <Info className="w-4 h-4 text-blue-400" />
                      <span>من نحن (About Us)</span>
                    </button>

                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        onOpenContact();
                      }}
                      className="w-full px-4 py-2 flex items-center gap-2.5 text-slate-300 hover:text-white hover:bg-slate-800 transition text-right cursor-pointer"
                    >
                      <PhoneCall className="w-4 h-4 text-amber-400" />
                      <span>تواصل معنا</span>
                    </button>
                  </div>

                  <div className="py-1">
                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        onOpenKotlinCode();
                      }}
                      className="w-full px-4 py-2 flex items-center gap-2.5 text-purple-300 hover:text-white hover:bg-purple-950/40 transition text-right cursor-pointer font-medium"
                    >
                      <Code2 className="w-4 h-4 text-purple-400" />
                      <span>كود تطبيق أندرويد Kotlin</span>
                    </button>

                    <a
                      href="/mobiley-source-code.zip"
                      download="mobiley-source-code.zip"
                      onClick={() => setMenuOpen(false)}
                      className="w-full px-4 py-2 flex items-center gap-2.5 text-emerald-400 hover:text-emerald-300 hover:bg-emerald-950/40 transition text-right cursor-pointer font-medium"
                    >
                      <Download className="w-4 h-4 text-emerald-400" />
                      <span>تحميل السورس كود كاملاً (ZIP)</span>
                    </a>
                  </div>

                  {currentUser && (
                    <div className="py-1">
                      <button
                        onClick={() => {
                          setMenuOpen(false);
                          onLogout();
                        }}
                        className="w-full px-4 py-2 flex items-center gap-2.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition text-right cursor-pointer"
                      >
                        <LogOut className="w-4 h-4" />
                        <span>تسجيل الخروج</span>
                      </button>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>

          {/* Search Button close to the 3 dots */}
          <button
            onClick={() => {
              setIsSearchActive(!isSearchActive);
              if (isSearchActive) onSearchChange?.('');
            }}
            title={isSearchActive ? 'إغلاق البحث' : 'بحث'}
            className={`p-1.5 rounded-full transition active:scale-95 border cursor-pointer ${
              isSearchActive
                ? 'bg-slate-700 text-white border-slate-600'
                : 'bg-slate-800/90 hover:bg-slate-700 text-slate-200 hover:text-white border-slate-700/50'
            }`}
          >
            {isSearchActive ? <X className="w-4.5 h-4.5" /> : <Search className="w-4.5 h-4.5" />}
          </button>
        </div>

        {/* Center: Search input if active */}
        {isSearchActive && (
          <div className="flex-1 mx-2 relative animate-in fade-in duration-200">
            <input
              type="text"
              autoFocus
              placeholder="ابحث عن هاتف..."
              value={searchQuery}
              onChange={(e) => onSearchChange?.(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-full py-1 pr-7 pl-6 text-white placeholder-slate-400 focus:outline-none focus:border-slate-500 text-xs shadow-inner"
            />
            <Search className="w-3 h-3 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            {searchQuery && (
              <button
                onClick={() => onSearchChange?.('')}
                className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
        )}

        {/* Left Side: "Mobiley" stretched with wide tracking in gray */}
        <div className="shrink-0 flex items-center">
          <span className="text-2xl sm:text-3xl font-black tracking-[0.3em] scale-x-110 origin-left text-slate-400 hover:text-slate-300 font-sans select-none drop-shadow-sm transition cursor-default leading-none">
            Mobiley
          </span>
        </div>
      </div>
    </header>
  );
};
