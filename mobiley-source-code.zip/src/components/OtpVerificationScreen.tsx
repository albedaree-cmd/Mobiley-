import React, { useState, useEffect, useRef } from 'react';
import {
  ShieldCheck,
  RotateCcw,
  ArrowRight,
  MessageSquare,
  CheckCircle2,
  Copy,
  Check,
} from 'lucide-react';
import { ModernAnimatedPhone } from './ModernAnimatedPhone';

interface OtpVerificationScreenProps {
  phone: string;
  demoCode: string;
  onVerifySuccess: () => void;
  onBack: () => void;
}

export const OtpVerificationScreen: React.FC<OtpVerificationScreenProps> = ({
  phone,
  demoCode,
  onVerifySuccess,
  onBack,
}) => {
  const [digits, setDigits] = useState(['', '', '', '']);
  const [timer, setTimer] = useState(60);
  const [errorMsg, setErrorMsg] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showWaBanner, setShowWaBanner] = useState(true);
  const inputsRef = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    if (timer > 0) {
      const interval = setInterval(() => setTimer((t) => t - 1), 1000);
      return () => clearInterval(interval);
    }
  }, [timer]);

  const handleInputChange = (idx: number, val: string) => {
    const clean = val.replace(/\D/g, '').slice(-1);
    const newDigits = [...digits];
    newDigits[idx] = clean;
    setDigits(newDigits);
    setErrorMsg('');

    if (clean && idx < 3) {
      inputsRef.current[idx + 1]?.focus();
    }
  };

  const handleKeyDown = (idx: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !digits[idx] && idx > 0) {
      inputsRef.current[idx - 1]?.focus();
    }
  };

  const handleAutoFill = () => {
    const chars = demoCode.split('').slice(0, 4);
    setDigits(chars);
    setErrorMsg('');
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(demoCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleVerify = () => {
    const entered = digits.join('');
    if (entered.length < 4) {
      setErrorMsg('يرجى إدخال جميع خانات الكود الأربعة');
      return;
    }

    if (entered !== demoCode) {
      setErrorMsg('كود التحقق غير صحيح، يرجى التأكد والمحاولة مجدداً');
      return;
    }

    setIsVerifying(true);

    setTimeout(() => {
      setIsVerifying(false);
      onVerifySuccess();
    }, 500);
  };

  return (
    <div className="min-h-screen w-full bg-slate-950 flex flex-col justify-between p-4 max-w-md mx-auto relative overflow-y-auto">
      {/* WhatsApp Simulated Incoming Notification Banner */}
      {showWaBanner && (
        <div className="fixed top-3 left-4 right-4 max-w-md mx-auto z-50 bg-[#128C7E] text-white p-3 rounded-2xl shadow-2xl flex items-center justify-between border border-emerald-400/40 animate-bounce">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center shrink-0">
              <MessageSquare className="w-4 h-4 text-white" />
            </div>
            <div className="text-right">
              <p className="text-[10px] font-bold text-emerald-200">رسالة جديدة من WhatsApp</p>
              <p className="text-xs font-mono font-bold">
                كود التحقق الخاص بك هو: <span className="underline tracking-wider font-black text-amber-300">{demoCode}</span>
              </p>
            </div>
          </div>
          <button
            onClick={() => setShowWaBanner(false)}
            className="text-xs text-white/80 hover:text-white px-2 py-1 rounded-lg bg-black/20"
          >
            إغلاق
          </button>
        </div>
      )}

      {/* Top Header */}
      <div className="flex items-center justify-between pt-2 pb-1">
        <button
          onClick={onBack}
          className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white transition flex items-center gap-1.5 text-xs cursor-pointer"
        >
          <ArrowRight className="w-4 h-4" />
          <span>تعديل البيانات</span>
        </button>
        <span className="text-xs font-mono text-emerald-400">تأكيد واتساب</span>
      </div>

      {/* Modern Animated Smartphone Icon */}
      <div className="flex flex-col items-center text-center my-3">
        <ModernAnimatedPhone size="lg" showWaves={true} isFloating={true} className="mb-3" />

        <h2 className="text-2xl font-black text-white">تأكيد كود الهاتف</h2>
        <p className="text-xs text-slate-400 mt-1 max-w-xs">
          أدخل كود التحقق المرسل إلى رقم الواتساب: <span className="text-emerald-400 font-mono font-bold" dir="ltr">{phone}</span>
        </p>
      </div>

      {/* Verification Card */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl backdrop-blur-md mb-4 text-center">
        {/* Demo Fast Hint Banner with WhatsApp direct link */}
        <div className="mb-4 p-3 bg-emerald-950/70 border border-emerald-600/40 rounded-2xl flex items-center justify-between gap-2 text-xs text-emerald-300">
          <div className="flex items-center gap-2 text-right">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <div>
              <p className="font-semibold text-[11px]">كود الواتساب:</p>
              <p className="font-mono text-base font-black tracking-widest text-white">{demoCode}</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={handleCopyCode}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs transition cursor-pointer"
              title="نسخ الكود"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
            <button
              onClick={handleAutoFill}
              className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs transition cursor-pointer"
            >
              تعبئة تلقائية
            </button>
          </div>
        </div>

        {/* 4 Digit Boxes */}
        <div className="flex justify-center gap-3 mb-4" dir="ltr">
          {digits.map((digit, idx) => (
            <input
              key={idx}
              ref={(el) => {
                inputsRef.current[idx] = el;
              }}
              type="text"
              inputMode="numeric"
              maxLength={1}
              value={digit}
              onChange={(e) => handleInputChange(idx, e.target.value)}
              onKeyDown={(e) => handleKeyDown(idx, e)}
              className="w-14 h-16 bg-slate-950 border-2 border-slate-700/80 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30 rounded-2xl text-center text-2xl font-bold font-mono text-white transition-all shadow-inner"
            />
          ))}
        </div>

        {errorMsg && <p className="text-rose-400 text-xs font-medium mb-3">{errorMsg}</p>}

        {/* Verify Action Button */}
        <button
          onClick={handleVerify}
          disabled={isVerifying}
          className="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-bold rounded-2xl transition shadow-lg shadow-emerald-950/50 flex items-center justify-center gap-2 active:scale-[0.98] cursor-pointer"
        >
          {isVerifying ? (
            <span className="text-sm">جارٍ التحقق وتأكيد الدخول...</span>
          ) : (
            <>
              <ShieldCheck className="w-4 h-4" />
              <span className="text-sm">تأكيد الرمز والدخول إلى الحساب</span>
            </>
          )}
        </button>

        {/* Resend Timer */}
        <div className="mt-3 flex items-center justify-center gap-2 text-xs text-slate-400">
          {timer > 0 ? (
            <span>إعادة إرسال كود واتساب خلال: <strong className="font-mono text-emerald-400">{timer} ثانية</strong></span>
          ) : (
            <button
              onClick={() => {
                setTimer(60);
                setErrorMsg('');
                setShowWaBanner(true);
              }}
              className="text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>إعادة إرسال الكود مجدداً</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
