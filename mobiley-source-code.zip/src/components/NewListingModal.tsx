import React, { useState, useRef } from 'react';
import {
  X,
  Camera,
  MapPin,
  Tag,
  DollarSign,
  FileText,
  AlertCircle,
  Trash2,
} from 'lucide-react';
import { SUDAN_CITIES } from '../data/sudanData';
import { sanitizeInput } from '../services/supabaseService';

interface NewListingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: {
    title: string;
    model: string;
    price: number;
    city: string;
    locationDetails: string;
    notes: string;
    images: string[];
  }) => void;
}

export const NewListingModal: React.FC<NewListingModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
}) => {
  const [title, setTitle] = useState('');
  const [model, setModel] = useState('');
  const [price, setPrice] = useState('');
  const [city, setCity] = useState(SUDAN_CITIES[0]);
  const [locationDetails, setLocationDetails] = useState('');
  const [notes, setNotes] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [errorMsg, setErrorMsg] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  // Handle local memory/device image file upload (up to 6 photos)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const availableSlots = 6 - images.length;
    if (availableSlots <= 0) {
      setErrorMsg('الحد الأقصى المسموح به هو 6 صور فقط');
      return;
    }

    const filesToLoad: File[] = Array.from(files).slice(0, availableSlots) as File[];
    filesToLoad.forEach((file: File) => {
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        const result = uploadEvent.target?.result as string;
        if (result) {
          setImages((prev) => (prev.length < 6 ? [...prev, result] : prev));
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleRemoveImage = (idx: number) => {
    setImages((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!title.trim()) {
      setErrorMsg('يرجى كتابة عنوان العرض واسم الهاتف');
      return;
    }
    if (!model.trim()) {
      setErrorMsg('يرجى تحديد موديل الهاتف');
      return;
    }
    if (!price || Number(price) <= 0) {
      setErrorMsg('يرجى إدخال سعر صحيح للجهاز');
      return;
    }
    if (!notes.trim()) {
      setErrorMsg('يرجى كتابة ملاحظات حول حالة الهاتف');
      return;
    }
    if (notes.length > 50) {
      setErrorMsg('الملاحظات يجب ألا تتجاوز 50 حرفاً كحد أقصى');
      return;
    }

    const finalImages =
      images.length > 0
        ? images
        : ['https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=800&auto=format&fit=crop&q=80'];

    onSubmit({
      title: sanitizeInput(title),
      model: sanitizeInput(model),
      price: Number(price),
      city,
      locationDetails: sanitizeInput(locationDetails) || 'سوق الهواتف',
      notes: sanitizeInput(notes, 50),
      images: finalImages,
    });

    // Reset
    setTitle('');
    setModel('');
    setPrice('');
    setNotes('');
    setImages([]);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm overflow-y-auto">
      {/* Dialog container - without toolbar or text header above */}
      <div className="w-full max-w-sm md:max-w-md bg-slate-900 border border-slate-700/80 rounded-3xl p-5 shadow-2xl relative my-auto max-h-[92vh] flex flex-col overflow-hidden">
        {/* Sleek floating close button without toolbar or top text */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-3.5 left-3.5 z-20 p-2 rounded-full bg-slate-800/90 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer border border-slate-700/60 shadow-md"
          title="إغلاق"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto pt-2 pb-1 space-y-3.5 pr-1">
          {errorMsg && (
            <div className="p-2.5 bg-rose-500/15 border border-rose-500/30 rounded-xl text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* 1. Centered Image Upload Icon & Area as requested */}
          <div className="pt-2 flex flex-col items-center justify-center">
            {/* Hidden native file input */}
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              multiple
              onChange={handleFileUpload}
              className="hidden"
            />

            {/* Prominent Centered Upload Button */}
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-full max-w-xs py-4 px-4 rounded-3xl border-2 border-dashed border-emerald-500/50 hover:border-emerald-400 bg-slate-950/70 hover:bg-slate-950/95 flex flex-col items-center justify-center gap-2 transition group cursor-pointer shadow-inner"
            >
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 group-hover:bg-emerald-500/30 text-emerald-400 flex items-center justify-center transition-transform transform group-hover:scale-110 shadow-md shadow-emerald-950/40">
                <Camera className="w-6 h-6 text-emerald-400" />
              </div>
              <span className="text-sm font-bold text-white group-hover:text-emerald-300 transition">
                إضافة
              </span>
              <span className="text-[10px] text-slate-400">
                (حتى 6 صور • المرفوع حالياً: {images.length} / 6)
              </span>
            </button>

            {/* Uploaded Images Preview Grid */}
            {images.length > 0 && (
              <div className="w-full grid grid-cols-3 gap-2 mt-3">
                {images.map((imgUrl, idx) => (
                  <div
                    key={idx}
                    className="relative aspect-square rounded-2xl bg-slate-950 border border-slate-700 overflow-hidden group"
                  >
                    <img src={imgUrl} alt={`هاتف ${idx + 1}`} className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => handleRemoveImage(idx)}
                      className="absolute top-1 right-1 w-6 h-6 rounded-full bg-rose-600/90 hover:bg-rose-500 text-white flex items-center justify-center transition cursor-pointer shadow-md"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* 2. Phone Name & Model */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                اسم الهاتف
              </label>
              <div className="relative flex items-center">
                <div className="absolute right-2.5 text-slate-400 pointer-events-none">
                  <Tag className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <input
                  type="text"
                  placeholder="iPhone 15 Pro Max"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-2xl py-2 pr-8 pl-3 text-white text-xs focus:border-emerald-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                موديل الجهاز
              </label>
              <input
                type="text"
                placeholder="A3106 - 256GB"
                value={model}
                onChange={(e) => setModel(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-2xl py-2 px-3 text-white text-xs focus:border-emerald-500 focus:outline-none"
              />
            </div>
          </div>

          {/* 3. Price */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              السعر
            </label>
            <div className="relative flex items-center">
              <div className="absolute right-3 text-slate-400 pointer-events-none">
                <DollarSign className="w-4 h-4 text-emerald-400" />
              </div>
              <input
                type="number"
                dir="ltr"
                placeholder="1500000"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-2xl py-2.5 pr-10 pl-14 text-white text-sm font-mono font-bold focus:border-emerald-500 focus:outline-none"
              />
              <div className="absolute left-3 text-xs font-bold text-slate-400">ج.س</div>
            </div>
          </div>

          {/* 4. Location Fields: City & Area */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">المدينة</label>
              <div className="relative flex items-center">
                <div className="absolute right-2.5 text-slate-400 pointer-events-none">
                  <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <select
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-2xl py-2 pr-8 pl-2 text-white text-xs focus:border-emerald-500 focus:outline-none cursor-pointer"
                >
                  {SUDAN_CITIES.map((c) => (
                    <option key={c} value={c} className="bg-slate-900">
                      {c}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                تفاصيل الموقع / الحي
              </label>
              <input
                type="text"
                placeholder="السوق الكبير أو الرياض"
                value={locationDetails}
                onChange={(e) => setLocationDetails(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-2xl py-2 px-3 text-white text-xs focus:border-emerald-500 focus:outline-none"
              />
            </div>
          </div>

          {/* 5. Notes (Strict 50-character limit as required) */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1">
                <FileText className="w-3.5 h-3.5 text-emerald-400" />
                <span>ملاحظات (50 حرفاً كحد أقصى)</span>
              </label>
              <span
                className={`text-[11px] font-mono font-bold ${
                  notes.length > 45 ? 'text-amber-400' : 'text-slate-400'
                }`}
              >
                {notes.length} / 50 حرف
              </span>
            </div>
            <textarea
              rows={2}
              maxLength={50}
              placeholder="بطارية 95% بدون خدش مع الكرتونة والشاحن الأصلي"
              value={notes}
              onChange={(e) => setNotes(e.target.value.slice(0, 50))}
              className="w-full bg-slate-950 border border-slate-700 rounded-2xl p-2.5 text-white text-xs focus:border-emerald-500 focus:outline-none resize-none"
            />
          </div>

          {/* Expiration Note */}
          <div className="p-2.5 bg-amber-500/10 border border-amber-500/20 rounded-2xl text-[11px] text-amber-300">
            ⏰ تنبيه: سيظل هذا العرض معروضاً لمدة 7 أيام ثم يُحذف تلقائياً لضمان تحديث الأسعار.
          </div>

          {/* 6. Publish Button at the Bottom */}
          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-bold text-base rounded-2xl transition shadow-lg shadow-emerald-950/50 flex items-center justify-center gap-2 active:scale-[0.98] cursor-pointer"
            >
              <span>نشر</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
