import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ModernAnimatedPhone } from './ModernAnimatedPhone';
import { Check } from 'lucide-react';

interface PullToRefreshContainerProps {
  onRefresh: () => Promise<void> | void;
  children: React.ReactNode;
}

export const PullToRefreshContainer: React.FC<PullToRefreshContainerProps> = ({
  onRefresh,
  children,
}) => {
  const [pullDistance, setPullDistance] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const startYRef = useRef(0);
  const isPullingRef = useRef(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const THRESHOLD = 75;

  const handleTouchStart = (e: React.TouchEvent) => {
    if (containerRef.current && containerRef.current.scrollTop <= 2) {
      startYRef.current = e.touches[0].clientY;
      isPullingRef.current = true;
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isPullingRef.current || isRefreshing) return;
    const currentY = e.touches[0].clientY;
    const diff = currentY - startYRef.current;
    if (diff > 0) {
      // Apply rubber-band damping
      const damped = Math.min(110, diff * 0.45);
      setPullDistance(damped);
    }
  };

  const handleTouchEnd = async () => {
    if (!isPullingRef.current) return;
    isPullingRef.current = false;

    if (pullDistance >= THRESHOLD && !isRefreshing) {
      triggerRefresh();
    } else {
      setPullDistance(0);
    }
  };

  // Mouse drag support for desktop/preview
  const handleMouseDown = (e: React.MouseEvent) => {
    if (containerRef.current && containerRef.current.scrollTop <= 2) {
      startYRef.current = e.clientY;
      isPullingRef.current = true;
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isPullingRef.current || isRefreshing) return;
    const diff = e.clientY - startYRef.current;
    if (diff > 0) {
      const damped = Math.min(110, diff * 0.45);
      setPullDistance(damped);
    }
  };

  const handleMouseUp = () => {
    if (!isPullingRef.current) return;
    isPullingRef.current = false;
    if (pullDistance >= THRESHOLD && !isRefreshing) {
      triggerRefresh();
    } else {
      setPullDistance(0);
    }
  };

  const triggerRefresh = async () => {
    setIsRefreshing(true);
    setPullDistance(THRESHOLD);
    try {
      await onRefresh();
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 800);
    } finally {
      setTimeout(() => {
        setIsRefreshing(false);
        setPullDistance(0);
      }, 500);
    }
  };

  return (
    <div
      ref={containerRef}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      className="relative w-full h-full overflow-y-auto select-none"
    >
      {/* Pull Down Indicator: ONLY appears when pulling down or refreshing */}
      <AnimatePresence>
        {(pullDistance > 10 || isRefreshing) && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{
              opacity: 1,
              height: Math.min(80, pullDistance),
            }}
            exit={{ opacity: 0, height: 0 }}
            className="w-full flex flex-col items-center justify-center overflow-hidden bg-slate-900/80 border-b border-slate-800/60"
          >
            <div className="flex items-center justify-center py-2">
              {showSuccess ? (
                <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                  <Check className="w-5 h-5" />
                </div>
              ) : (
                <div className="flex items-center justify-center">
                  {/* Miniature modern animated phone indicator with smooth rotation */}
                  <motion.div
                    animate={
                      isRefreshing
                        ? { rotate: 360, scale: [1, 1.15, 1] }
                        : { rotate: (pullDistance / THRESHOLD) * 180 }
                    }
                    transition={
                      isRefreshing
                        ? { duration: 0.9, repeat: Infinity, ease: 'linear' }
                        : { duration: 0.1 }
                    }
                  >
                    <ModernAnimatedPhone size="sm" showWaves={false} isFloating={false} />
                  </motion.div>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {children}
    </div>
  );
};
