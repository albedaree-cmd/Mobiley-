import React, { useEffect } from 'react';
import { motion } from 'motion/react';
import { ModernAnimatedPhone } from './ModernAnimatedPhone';
import { Sparkles } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
  onTriggerOfflineTest?: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  onComplete,
}) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete();
    }, 2200);

    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="relative min-h-screen w-full bg-gradient-to-b from-slate-950 via-slate-900 to-emerald-950/40 flex flex-col items-center justify-between p-6 select-none overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-60 h-60 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Bar */}
      <div className="w-full flex items-center justify-between z-10 pt-2">
        <span className="text-xs text-emerald-400/80 font-mono tracking-wider flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-amber-400" />
          <span>نسخة أندرويد 2.4.0</span>
        </span>
      </div>

      {/* Center Content: Animated Phone + "Mobiley" + 4 Loading Dots */}
      <div className="flex flex-col items-center justify-center my-auto z-10 text-center">
        <motion.div
          initial={{ scale: 0.7, opacity: 0, y: 30 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          transition={{ duration: 0.8, type: 'spring', damping: 20 }}
          className="mb-6"
        >
          <ModernAnimatedPhone size="xl" showWaves={true} isFloating={true} />
        </motion.div>

        {/* Mobiley wordmark - crisp, bright, bold, and high contrast */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35, duration: 0.7 }}
          className="flex flex-col items-center"
        >
          <h1 className="text-5xl md:text-6xl font-black tracking-wider text-white font-sans drop-shadow-[0_4px_20px_rgba(0,0,0,0.95)] select-none">
            Mobiley
          </h1>

          <div className="h-1.5 w-16 bg-emerald-400 rounded-full mt-2.5 mb-4 shadow-lg shadow-emerald-500/50" />

          {/* 4 Loading Dots as requested - refined, smaller and elegant */}
          <div className="flex items-center gap-1.5 mt-2.5">
            {[0, 1, 2, 3].map((dotIndex) => (
              <motion.span
                key={dotIndex}
                animate={{
                  scale: [1, 1.4, 1],
                  opacity: [0.3, 1, 0.3],
                  backgroundColor: ['#10b981', '#34d399', '#10b981'],
                }}
                transition={{
                  duration: 1.0,
                  repeat: Infinity,
                  delay: dotIndex * 0.2,
                  ease: 'easeInOut',
                }}
                className="w-1.5 h-1.5 rounded-full shadow-sm shadow-emerald-500/30"
              />
            ))}
          </div>
        </motion.div>
      </div>

      {/* Empty bottom spacer to keep center content vertically balanced */}
      <div className="h-8 z-10" />
    </div>
  );
};
